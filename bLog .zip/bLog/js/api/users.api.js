/**
 * BlogHub - Users API Module
 * MockAPI resource: /users
 */

const UsersAPI = (() => {
  const ENDPOINT = '/users';
  const ADMIN = CONSTANTS.ADMIN_ACCOUNT;

  const toSessionUser = (user) => ({
    id: user.id,
    name: user.name || user.username || user.email?.split('@')[0] || 'User',
    email: user.email,
    avatar: user.avatar || Helpers.getAvatarUrl(user.name || user.email || 'User'),
    role: 'user',
  });

  const getAdminUser = () => ({
    id: 'admin-local',
    name: ADMIN.name,
    email: ADMIN.email,
    avatar: Helpers.getAvatarUrl(ADMIN.name),
    role: ADMIN.role,
  });

  const getByEmail = async (email) => {
    let users = [];
    try {
      users = await API.get(ENDPOINT, { email });
    } catch (err) {
      if (err.status === 404) return null;
      throw err;
    }
    if (!Array.isArray(users)) return null;
    return users.find(user => String(user.email).toLowerCase() === String(email).toLowerCase()) || null;
  };

  const register = async ({ name, email, password }) => {
    if (String(email).toLowerCase() === ADMIN.email) {
      throw new Error('Email này là tài khoản admin có sẵn. Vui lòng dùng email khác.');
    }

    const existed = await getByEmail(email);
    if (existed) {
      throw new Error('Email này đã được đăng ký. Vui lòng đăng nhập hoặc dùng email khác.');
    }

    const payload = {
      name,
      email,
      password,
      role: 'user',
      avatar: Helpers.getAvatarUrl(name || email),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const user = await API.post(ENDPOINT, payload);
    return toSessionUser(user);
  };

  const login = async ({ email, password }) => {
    const normalizedEmail = String(email).toLowerCase();
    if (normalizedEmail === ADMIN.email && password === ADMIN.password) {
      return getAdminUser();
    }

    const user = await getByEmail(email);
    if (!user || user.password !== password) {
      throw new Error('Email hoặc mật khẩu không đúng.');
    }

    return toSessionUser(user);
  };

  return { getByEmail, register, login, toSessionUser, getAdminUser };
})();
