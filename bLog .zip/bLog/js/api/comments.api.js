/**
 * BlogHub - Comments API Module
 */

const CommentsAPI = (() => {
  const ENDPOINT = '/comments';
  const BASE_URL = API.BLOG_META_BASE_URL;

  const getAll = async (params = {}) => {
    try {
      return await API.get(ENDPOINT, params, BASE_URL);
    } catch (err) {
      if (err.status === 404) return [];
      throw err;
    }
  };

  const getByPostId = async (postId, page = 1, limit = 20) => {
    try {
      return await API.get(ENDPOINT, { postId, page, limit, sortBy: 'createdAt', order: 'desc' }, BASE_URL);
    } catch (err) {
      if (err.status === 404) return [];
      throw err;
    }
  };

  const create = async (commentData) => {
    const payload = {
      ...commentData,
      createdAt: new Date().toISOString(),
      status: 'pending',
      likes: 0,
    };
    return await API.post(ENDPOINT, payload, BASE_URL);
  };

  const update = async (id, updates) => {
    return await API.put(`${ENDPOINT}/${id}`, {
      ...updates,
      updatedAt: new Date().toISOString(),
    }, BASE_URL);
  };

  const approve = async (id) => {
    return await update(id, { status: 'approved' });
  };

  const reject = async (id) => {
    return await update(id, { status: 'rejected' });
  };

  const remove = async (id) => {
    return await API.del(`${ENDPOINT}/${id}`, BASE_URL);
  };

  const getRecent = async (limit = 5) => {
    return await API.get(ENDPOINT, { limit, sortBy: 'createdAt', order: 'desc' }, BASE_URL);
  };

  const getPending = async () => {
    return await API.get(ENDPOINT, { status: 'pending', limit: 100 }, BASE_URL);
  };

  return { getAll, getByPostId, create, update, approve, reject, remove, getRecent, getPending, BASE_URL };
})();
