/**
 * BlogHub - Posts API Module
 * All CRUD operations for blog posts
 */

const PostsAPI = (() => {
  const ENDPOINT = '/posts';

  const normalizeTags = (tags) => {
    if (Array.isArray(tags)) return tags.map(t => String(t).trim()).filter(Boolean);
    if (typeof tags === 'string') return tags.split(',').map(t => t.trim()).filter(Boolean);
    return [];
  };

  const normalizePost = (post) => {
    // Map MockAPI auto-generated strings to valid valid types
    let status = post.status;
    if (status !== 'published' && status !== 'draft' && status !== 'archived') {
      // MockAPI auto-generates "status 1", "status 2" etc.
      status = Number(post.id) % 3 === 0 ? 'draft' : 'published';
    }

    let thumbnail = post.thumbnail || post.image;
    if (!thumbnail || !thumbnail.startsWith('http') && !thumbnail.startsWith('assets/')) {
      thumbnail = 'assets/images/post-default.png';
    }

    return {
      ...post,
      status,
      thumbnail,
      excerpt: post.excerpt || post.content?.substring(0, 100) + '...',
      tags: normalizeTags(post.tags)
    };
  };

  /**
   * Lấy danh sách tất cả bài viết (hoặc theo bộ lọc)
   * @param {Object} filters - Các tham số lọc (trạng thái, danh mục...)
   * @returns {Promise<Array>} Danh sách bài viết
   */
  const getAll = async (filters = {}) => {
    const posts = await API.get('/posts', filters);
    return posts.map(normalizePost);
  };

  /**
   * Fetch a single post by ID
   * @param {string|number} id
   */
  const getById = async (id) => {
    const post = await API.get(`/posts/${id}`);
    return normalizePost(post);
  };

  /**
   * Fetch posts with pagination
   * @param {number} page
   * @param {number} limit
   * @param {object} filters
   */
  const getPaginated = async (page = 1, limit = 10, filters = {}) => {
    const params = { page, limit, ...filters };
    return await API.get(ENDPOINT, params);
  };

  /**
   * Search posts by title or content
   * @param {string} query
   * @param {number} limit
   */
  const search = async (query, limit = 8) => {
    // MockAPI uses title filter
    return await API.get(ENDPOINT, { title: query, limit });
  };

  /**
   * Get trending posts (most liked)
   * @param {number} limit
   */
  const getTrending = async (limit = 5) => {
    const posts = await API.get(ENDPOINT, { limit: 50 });
    if (!Array.isArray(posts)) return [];
    return posts
      .sort((a, b) => (b.likes || 0) - (a.likes || 0))
      .slice(0, limit);
  };

  /**
   * Get latest posts
   * @param {number} limit
   */
  const getLatest = async (limit = 9) => {
    return await API.get(ENDPOINT, { limit, sortBy: 'createdAt', order: 'desc' });
  };

  /**
   * Get posts by tag
   * @param {string} tag
   */
  const getByTag = async (tag, limit = 9) => {
    const posts = await API.get(ENDPOINT, { limit: 100 });
    if (!Array.isArray(posts)) return [];
    return posts.filter(p =>
      Array.isArray(p.tags) && p.tags.some(t =>
        t.toLowerCase() === tag.toLowerCase()
      )
    ).slice(0, limit);
  };

  /**
   * Create a new post
   * @param {object} postData
   */
  const create = async (postData) => {
    const thumbnail = postData.thumbnail || postData.image || 'assets/images/post-default.png';
    const payload = {
      ...postData,
      image: thumbnail,
      thumbnail,
      excerpt: postData.excerpt || `${postData.content || ''}`.substring(0, 160),
      tags: normalizeTags(postData.tags),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      likes: 0,
      views: 0,
      status: postData.status || 'published',
    };
    const post = await API.post(ENDPOINT, payload);
    console.info('Saved post to MockAPI:', API.POSTS_URL, post);
    return post;
  };

  /**
   * Update an existing post
   * @param {string|number} id
   * @param {object} updates
   */
  const update = async (id, updates) => {
    const payload = { ...updates, updatedAt: new Date().toISOString() };
    return await API.put(`${ENDPOINT}/${id}`, payload);
  };

  /**
   * Delete a post
   * @param {string|number} id
   */
  const remove = async (id) => {
    return await API.del(`${ENDPOINT}/${id}`);
  };

  /**
   * Increment post views (using jQuery $.ajax)
   * @param {string|number} id
   * @param {number} currentViews
   */
  const incrementViews = (id, currentViews = 0) => {
    return $.ajax({
      url: `${API.BASE_URL}${ENDPOINT}/${id}`,
      method: 'PUT',
      contentType: 'application/json',
      data: JSON.stringify({ views: currentViews + 1 }),
    });
  };

  /**
   * Like a post
   * @param {string|number} id
   * @param {number} currentLikes
   */
  const like = async (id, currentLikes = 0) => {
    return await API.put(`${ENDPOINT}/${id}`, { likes: currentLikes + 1 });
  };

  /**
   * Get related posts by tags
   * @param {string[]} tags
   * @param {string|number} excludeId
   */
  const getRelated = async (tags = [], excludeId, limit = 3) => {
    const posts = await API.get(ENDPOINT, { limit: 50 });
    if (!Array.isArray(posts)) return [];

    return posts
      .filter(p =>
        p.id != excludeId &&
        Array.isArray(p.tags) &&
        p.tags.some(t => tags.includes(t))
      )
      .slice(0, limit);
  };

  return { getAll, getById, getPaginated, search, getTrending, getLatest, getByTag, create, update, remove, incrementViews, like, getRelated };
})();
