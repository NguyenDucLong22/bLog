/**
 * BlogHub - Tags API Module
 */

const TagsAPI = (() => {
  const ENDPOINT = '/tags';
  const BASE_URL = API.BLOG_META_BASE_URL;

  const getAll = async () => {
    // jQuery $.get for required jQuery usage
    return new Promise((resolve, reject) => {
      $.get(`${BASE_URL}${ENDPOINT}`)
        .done(resolve)
        .fail((xhr) => reject(new Error(xhr.responseJSON?.message || 'Failed to load tags')));
    });
  };

  const getById = async (id) => {
    return await API.get(`${ENDPOINT}/${id}`, {}, BASE_URL);
  };

  const create = async (tagData) => {
    const payload = {
      ...tagData,
      createdAt: new Date().toISOString(),
      postCount: 0,
    };
    return await API.post(ENDPOINT, payload, BASE_URL);
  };

  const update = async (id, updates) => {
    return await API.put(`${ENDPOINT}/${id}`, updates, BASE_URL);
  };

  const remove = async (id) => {
    return await API.del(`${ENDPOINT}/${id}`, BASE_URL);
  };

  const getPopular = async (limit = 10) => {
    const tags = await getAll();
    if (!Array.isArray(tags)) return [];
    return tags
      .sort((a, b) => (b.postCount || 0) - (a.postCount || 0))
      .slice(0, limit);
  };

  return { getAll, getById, create, update, remove, getPopular, BASE_URL };
})();
