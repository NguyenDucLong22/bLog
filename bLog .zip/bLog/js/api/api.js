/**
 * BlogHub - API Base Layer
 * Centralized HTTP client with error handling, loading states, and retry logic
 */

const API = (() => {
  // ── Configuration ──
  // MockAPI project chinh cua app.
  // 2 resource bat buoc:
  // - https://69e986ab55d62f34797a96da.mockapi.io/api/v1/posts
  // - https://69e986ab55d62f34797a96da.mockapi.io/api/v1/users
  // Comments/tags dang nam o project rieng:
  // - https://69e986ae55d62f34797a96e8.mockapi.io/api/v1/comments
  // - https://69e986ae55d62f34797a96e8.mockapi.io/api/v1/tags
  const BASE_URL = 'https://69e986ab55d62f34797a96da.mockapi.io/api/v1';
  const BLOG_META_BASE_URL = 'https://69e986ae55d62f34797a96e8.mockapi.io/api/v1';
  const POSTS_URL = `${BASE_URL}/posts`;
  const USERS_URL = `${BASE_URL}/users`;
  const COMMENTS_URL = `${BLOG_META_BASE_URL}/comments`;
  const TAGS_URL = `${BLOG_META_BASE_URL}/tags`;
  const TIMEOUT_MS = 10000;
  const MAX_RETRIES = 2;

  // ── Internal state ──
  let activeRequests = 0;

  /**
   * Perform an HTTP request with full error handling
   * @param {string} endpoint - API endpoint path
   * @param {object} options  - Fetch options
   * @param {number} retry    - Current retry attempt
   */
  const request = async (endpoint, options = {}, retry = 0) => {
    const { baseURL = BASE_URL, ...fetchOptions } = options;
    const url = `${baseURL}${endpoint}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), TIMEOUT_MS);

    activeRequests++;

    const defaultHeaders = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    const config = {
      ...fetchOptions,
      signal: controller.signal,
      headers: { ...defaultHeaders, ...fetchOptions.headers },
    };

    try {
      const response = await fetch(url, config);
      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new APIError(
          errorData.message || `HTTP ${response.status}: ${response.statusText}`,
          response.status,
          errorData
        );
      }

      // Handle 204 No Content
      if (response.status === 204) return null;

      return await response.json();

    } catch (error) {
      clearTimeout(timeoutId);

      // Retry on network errors
      if (retry < MAX_RETRIES && !(error instanceof APIError)) {
        await delay(1000 * (retry + 1));
        return request(endpoint, options, retry + 1);
      }

      if (error.name === 'AbortError') {
        throw new APIError('Request timed out. Please try again.', 408);
      }

      throw error;

    } finally {
      activeRequests--;
    }
  };

  /**
   * GET request
   */
  const get = (endpoint, params = {}, baseURL = BASE_URL) => {
    const queryString = new URLSearchParams(params).toString();
    const url = queryString ? `${endpoint}?${queryString}` : endpoint;
    return request(url, { method: 'GET', baseURL });
  };

  /**
   * POST request
   */
  const post = (endpoint, data, baseURL = BASE_URL) => {
    return request(endpoint, {
      method: 'POST',
      body: JSON.stringify(data),
      baseURL,
    });
  };

  /**
   * PUT request
   */
  const put = (endpoint, data, baseURL = BASE_URL) => {
    return request(endpoint, {
      method: 'PUT',
      body: JSON.stringify(data),
      baseURL,
    });
  };

  /**
   * DELETE request
   */
  const del = (endpoint, baseURL = BASE_URL) => {
    return request(endpoint, { method: 'DELETE', baseURL });
  };

  /**
   * jQuery $.ajax wrapper for compatibility requirement
   */
  const ajaxGet = (endpoint, params = {}, baseURL = BASE_URL) => {
    const queryString = new URLSearchParams(params).toString();
    const url = `${baseURL}${endpoint}${queryString ? '?' + queryString : ''}`;
    return $.ajax({ url, method: 'GET', dataType: 'json' });
  };

  const ajaxPost = (endpoint, data, baseURL = BASE_URL) => {
    const url = `${baseURL}${endpoint}`;
    return $.ajax({
      url,
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(data),
      dataType: 'json',
    });
  };

  /**
   * Helper: delay
   */
  const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  /**
   * Get number of active requests
   */
  const getActiveRequests = () => activeRequests;

  return {
    get,
    post,
    put,
    del,
    ajaxGet,
    ajaxPost,
    getActiveRequests,
    BASE_URL,
    BLOG_META_BASE_URL,
    POSTS_URL,
    USERS_URL,
    COMMENTS_URL,
    TAGS_URL,
  };
})();

/**
 * Custom API Error class
 */
class APIError extends Error {
  constructor(message, status, data = {}) {
    super(message);
    this.name = 'APIError';
    this.status = status;
    this.data = data;
  }
}

// Export for module use
if (typeof module !== 'undefined') module.exports = { API, APIError };
