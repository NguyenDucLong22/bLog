/**
 * BlogHub - Pagination Component
 */

const Pagination = (() => {
  /**
   * Render pagination buttons
   * @param {HTMLElement} container
   * @param {number} currentPage
   * @param {number} totalPages
   * @param {function} onPageChange - callback(page)
   */
  const render = (container, currentPage, totalPages, onPageChange) => {
    if (!container || totalPages <= 1) {
      if (container) container.innerHTML = '';
      return;
    }

    const pages = getPageNumbers(currentPage, totalPages);

    let html = `<div class="pagination-custom">`;

    // Prev button
    html += `
      <button class="page-btn" id="prevPage" ${currentPage === 1 ? 'disabled' : ''} title="Previous page">
        <i class="bi bi-chevron-left"></i>
      </button>
    `;

    // Page numbers
    pages.forEach(page => {
      if (page === '...') {
        html += `<span class="page-btn" style="cursor:default;border:none;">…</span>`;
      } else {
        html += `
          <button class="page-btn ${page === currentPage ? 'active' : ''}" data-page="${page}">
            ${page}
          </button>
        `;
      }
    });

    // Next button
    html += `
      <button class="page-btn" id="nextPage" ${currentPage === totalPages ? 'disabled' : ''} title="Next page">
        <i class="bi bi-chevron-right"></i>
      </button>
    `;

    html += '</div>';
    container.innerHTML = html;

    // Attach events
    container.querySelectorAll('[data-page]').forEach(btn => {
      btn.addEventListener('click', () => {
        const page = parseInt(btn.dataset.page, 10);
        if (page !== currentPage) onPageChange(page);
      });
    });

    container.querySelector('#prevPage')?.addEventListener('click', () => {
      if (currentPage > 1) onPageChange(currentPage - 1);
    });

    container.querySelector('#nextPage')?.addEventListener('click', () => {
      if (currentPage < totalPages) onPageChange(currentPage + 1);
    });
  };

  /**
   * Calculate page numbers with ellipsis
   */
  const getPageNumbers = (current, total) => {
    if (total <= 7) {
      return Array.from({ length: total }, (_, i) => i + 1);
    }

    const pages = [];
    if (current <= 4) {
      for (let i = 1; i <= Math.min(5, total); i++) pages.push(i);
      pages.push('...');
      pages.push(total);
    } else if (current >= total - 3) {
      pages.push(1);
      pages.push('...');
      for (let i = total - 4; i <= total; i++) pages.push(i);
    } else {
      pages.push(1);
      pages.push('...');
      for (let i = current - 1; i <= current + 1; i++) pages.push(i);
      pages.push('...');
      pages.push(total);
    }

    return pages;
  };

  /**
   * Calculate total pages
   */
  const totalPages = (total, perPage) => Math.ceil(total / perPage);

  /**
   * Paginate an array locally
   */
  const paginate = (arr, page, perPage) => {
    const start = (page - 1) * perPage;
    return arr.slice(start, start + perPage);
  };

  return { render, totalPages, paginate, getPageNumbers };
})();
