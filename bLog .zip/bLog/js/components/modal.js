/**
 * BlogHub - Modal Component
 */

const Modal = (() => {
  /**
   * Show a confirmation dialog
   */
  const confirm = ({ title = 'Are you sure?', message = '', confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, type = 'danger' }) => {
    const id = Helpers.randomId('modal-');
    const colorMap = { danger: '#DC2626', warning: '#D97706', primary: 'var(--color-primary)' };
    const iconMap = { danger: 'bi-trash', warning: 'bi-exclamation-triangle', primary: 'bi-check-circle' };
    const color = colorMap[type] || colorMap.danger;
    const icon = iconMap[type] || iconMap.danger;

    const modalEl = document.createElement('div');
    modalEl.innerHTML = `
      <div class="modal fade" id="${id}" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-sm">
          <div class="modal-content">
            <div class="modal-body text-center p-4">
              <div style="width:60px;height:60px;background:${color}15;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1rem;">
                <i class="bi ${icon}" style="font-size:1.5rem;color:${color};"></i>
              </div>
              <h5 style="font-weight:700;margin-bottom:0.5rem;">${title}</h5>
              <p style="font-size:0.875rem;color:var(--text-secondary);margin-bottom:1.5rem;">${message}</p>
              <div class="d-flex gap-2 justify-content-center">
                <button class="btn btn-light btn-sm px-4" data-bs-dismiss="modal">${cancelText}</button>
                <button class="btn btn-sm px-4 confirm-btn" style="background:${color};color:white;border:none;">${confirmText}</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(modalEl.firstElementChild);
    const modalInstance = new bootstrap.Modal(document.getElementById(id));
    modalInstance.show();

    document.getElementById(id).querySelector('.confirm-btn').addEventListener('click', () => {
      modalInstance.hide();
      if (typeof onConfirm === 'function') onConfirm();
    });

    document.getElementById(id).addEventListener('hidden.bs.modal', () => {
      document.getElementById(id)?.remove();
    });
  };

  /**
   * Show/hide Bootstrap modal by id
   */
  const show = (id) => {
    const el = document.getElementById(id);
    if (el) bootstrap.Modal.getOrCreateInstance(el).show();
  };

  const hide = (id) => {
    const el = document.getElementById(id);
    if (el) bootstrap.Modal.getInstance(el)?.hide();
  };

  return { confirm, show, hide };
})();
