/**
 * BlogHub - Cards Component
 * Render different types of post cards
 */

const Cards = (() => {
  /**
   * Render a standard post card
   */
  const postCard = (post) => {
    const image = post.image || `https://picsum.photos/seed/${post.id}/800/500`;
    const tags = Array.isArray(post.tags) ? post.tags : [];
    const tag = tags[0] || 'Blog';
    const avatar = post.authorAvatar || Helpers.getAvatarUrl(post.author || 'Author');
    const readTime = Formatters.readingTime(post.content || post.excerpt || '');

    return `
      <article class="post-card-article reveal">
        <div class="post-card-img-wrapper">
          <img src="${image}" alt="${post.title}" class="post-card-img"
               loading="lazy" onerror="this.src='https://picsum.photos/seed/${Math.random()}/800/500'">
          <div class="post-card-category">
            <span class="badge-custom badge-primary">${tag}</span>
          </div>
        </div>
        <div class="post-card-body">
          <div class="post-card-meta">
            <span><i class="bi bi-calendar3"></i> ${Formatters.formatDate(post.createdAt)}</span>
            <span><i class="bi bi-clock"></i> ${readTime}</span>
          </div>
          <a href="bai-viet.html?id=${post.id}" class="post-card-title">${post.title}</a>
          <p class="post-card-excerpt">${post.excerpt || Helpers.truncate(Helpers.stripHtml(post.content || ''), 120)}</p>
          <div class="post-card-footer">
            <div class="post-card-author">
              <img src="${avatar}" alt="${post.author}" class="avatar avatar-xs" loading="lazy" onerror="this.src='${Helpers.getAvatarUrl(post.author || 'A')}'">
              <span class="post-card-author-name">${post.author || 'Anonymous'}</span>
            </div>
            <div class="post-card-stats">
              <span class="post-card-stat"><i class="bi bi-eye"></i> ${Formatters.formatNumber(post.views || 0)}</span>
              <span class="post-card-stat"><i class="bi bi-heart"></i> ${Formatters.formatNumber(post.likes || 0)}</span>
            </div>
          </div>
        </div>
      </article>
    `;
  };

  /**
   * Render a trending card (horizontal)
   */
  const trendingCard = (post, index) => {
    const image = post.image || `https://picsum.photos/seed/${post.id}/300/200`;
    return `
      <a href="bai-viet.html?id=${post.id}" class="trending-card reveal delay-${(index % 4) * 100}">
        <div class="trending-number">${String(index + 1).padStart(2, '0')}</div>
        <div class="trending-content">
          <div class="trending-title">${post.title}</div>
          <div class="trending-meta">
            <i class="bi bi-eye"></i> ${Formatters.formatNumber(post.views || 0)} · 
            <i class="bi bi-heart"></i> ${Formatters.formatNumber(post.likes || 0)}
          </div>
        </div>
        <img src="${image}" alt="${post.title}" class="trending-img" loading="lazy" onerror="this.src='https://picsum.photos/seed/${post.id + 100}/300/200'">
      </a>
    `;
  };

  /**
   * Render a comment card
   */
  const commentCard = (comment, canModerate = false, replies = [], canReply = true) => {
    const avatar = Helpers.getAvatarUrl(comment.name || 'User');
    const safeName = `${comment.name || 'Anonymous'}`.replace(/'/g, "\\'");
    return `
      <div class="comment-card" id="comment-${comment.id}">
        <div class="comment-author">
          <img src="${avatar}" alt="${comment.name}" class="avatar avatar-sm" onerror="this.src='${avatar}'">
          <div class="comment-author-info">
            <div class="comment-author-name">${comment.name || 'Anonymous'}</div>
            <div class="comment-date">${Formatters.timeAgo(comment.createdAt)}</div>
          </div>
          ${canModerate ? `
            <div class="ms-auto d-flex gap-1">
              <button class="action-btn approve" onclick="moderateComment('${comment.id}', 'approved')" title="Approve"><i class="bi bi-check"></i></button>
              <button class="action-btn delete" onclick="deleteComment('${comment.id}')" title="Delete"><i class="bi bi-trash"></i></button>
            </div>
          ` : ''}
        </div>
        <p class="comment-text">${comment.content || comment.text || ''}</p>
        <div class="comment-actions">
          <button class="comment-action-btn">
            <i class="bi bi-hand-thumbs-up"></i> <span>${comment.likes || 0}</span>
          </button>
          ${canReply ? `
            <button class="comment-action-btn" onclick="showReplyForm('${comment.id}', '${safeName}')">
              <i class="bi bi-reply"></i> Trả lời
            </button>
          ` : ''}
        </div>
        ${canReply ? `<div class="reply-form-slot" id="replyForm-${comment.id}"></div>` : ''}
        ${replies.length ? `
          <div class="comment-replies">
            ${replies.map(reply => commentCard(reply, canModerate, [], false)).join('')}
          </div>
        ` : ''}
      </div>
    `;
  };

  /**
   * Render a post row in management table
   */
  const postTableRow = (post) => {
    const tags = Array.isArray(post.tags) ? post.tags.slice(0, 2) : [];
    return `
      <tr data-id="${post.id}">
        <td>
          <img src="${post.image || 'https://picsum.photos/seed/' + post.id + '/100/80'}"
               alt="${post.title}" class="post-thumb" 
               onerror="this.src='https://picsum.photos/seed/${post.id + 50}/100/80'">
        </td>
        <td>
          <div class="post-title-cell">${post.title}</div>
          <div class="post-excerpt-cell">${post.excerpt || ''}</div>
          <div class="mt-1">${tags.map(t => `<span class="tag-pill" style="font-size:10px;padding:2px 8px;">${t}</span>`).join('')}</div>
        </td>
        <td>${Formatters.statusBadge(post.status)}</td>
        <td style="font-size:0.8125rem;color:var(--text-secondary);">${Formatters.formatDate(post.createdAt)}</td>
        <td style="font-size:0.8125rem;color:var(--text-secondary);">
          <i class="bi bi-eye"></i> ${Formatters.formatNumber(post.views || 0)}
          · <i class="bi bi-heart"></i> ${Formatters.formatNumber(post.likes || 0)}
        </td>
        <td>
          <div class="action-btn-group">
            <a href="bai-viet.html?id=${post.id}" class="action-btn view" title="View"><i class="bi bi-eye"></i></a>
            <button class="action-btn edit" title="Edit" onclick="openEditModal('${post.id}')"><i class="bi bi-pencil"></i></button>
            <button class="action-btn delete" title="Delete" onclick="confirmDelete('${post.id}', '${post.title.replace(/'/g, "\\'")}')"><i class="bi bi-trash"></i></button>
          </div>
        </td>
      </tr>
    `;
  };

  /**
   * Render tag card
   */
  const tagCard = (tag) => {
    const colorClass = `tag-color-${tag.color || 'purple'}`;
    const colors = CONSTANTS.TAG_COLORS.find(c => c.name === (tag.color || 'purple')) || CONSTANTS.TAG_COLORS[0];
    return `
      <div class="tag-card" data-id="${tag.id}">
        <div class="tag-card-icon" style="background:${colors.bg};color:${colors.value};">
          <i class="bi bi-hash"></i>
        </div>
        <div class="tag-card-name ${colorClass}">#${tag.name}</div>
        <div class="tag-card-count">${tag.postCount || 0} posts</div>
        <div class="tag-card-actions">
          <button class="action-btn edit" title="Edit" onclick="openEditTagModal('${tag.id}')"><i class="bi bi-pencil"></i></button>
          <button class="action-btn delete" title="Delete" onclick="confirmDeleteTag('${tag.id}', '${tag.name}')"><i class="bi bi-trash"></i></button>
        </div>
      </div>
    `;
  };

  return { postCard, trendingCard, commentCard, postTableRow, tagCard };
})();
