/**
 * BlogHub - Loader Component
 * Skeleton shimmer and loading states
 */

const Loader = (() => {
  /**
   * Show spinner inside an element
   */
  const showSpinner = (container, message = 'Loading...') => {
    if (!container) return;
    container.innerHTML = `
      <div class="loading-overlay">
        <div class="spinner-custom"></div>
        <p style="color:var(--text-tertiary);font-size:0.875rem;margin:0;">${message}</p>
      </div>
    `;
  };

  /**
   * Show skeleton cards
   * @param {HTMLElement} container
   * @param {number} count
   * @param {string} type - 'card' | 'row' | 'comment'
   */
  const showSkeleton = (container, count = 3, type = 'card') => {
    if (!container) return;

    const templates = {
      card: () => `
        <div class="card-custom p-0" style="overflow:hidden;">
          <div class="skeleton" style="height:200px;border-radius:var(--radius-xl) var(--radius-xl) 0 0;"></div>
          <div class="p-3">
            <div class="skeleton" style="height:12px;width:60%;margin-bottom:8px;"></div>
            <div class="skeleton" style="height:18px;width:90%;margin-bottom:6px;"></div>
            <div class="skeleton" style="height:18px;width:75%;margin-bottom:12px;"></div>
            <div class="skeleton" style="height:12px;width:80%;margin-bottom:6px;"></div>
            <div class="skeleton" style="height:12px;width:65%;margin-bottom:16px;"></div>
            <div class="d-flex align-items-center gap-2">
              <div class="skeleton" style="width:32px;height:32px;border-radius:50%;flex-shrink:0;"></div>
              <div class="skeleton" style="height:12px;width:100px;"></div>
              <div class="skeleton ms-auto" style="height:12px;width:60px;"></div>
            </div>
          </div>
        </div>`,

      row: () => `
        <tr>
          <td><div class="skeleton" style="height:40px;width:40px;border-radius:6px;"></div></td>
          <td>
            <div class="skeleton" style="height:14px;width:80%;margin-bottom:6px;"></div>
            <div class="skeleton" style="height:11px;width:60%;"></div>
          </td>
          <td><div class="skeleton" style="height:22px;width:70px;border-radius:99px;"></div></td>
          <td><div class="skeleton" style="height:12px;width:80px;"></div></td>
          <td><div class="skeleton" style="height:12px;width:50px;"></div></td>
          <td>
            <div class="d-flex gap-1">
              <div class="skeleton" style="width:32px;height:32px;border-radius:6px;"></div>
              <div class="skeleton" style="width:32px;height:32px;border-radius:6px;"></div>
            </div>
          </td>
        </tr>`,

      comment: () => `
        <div class="comment-card">
          <div class="d-flex align-items-center gap-2 mb-2">
            <div class="skeleton" style="width:40px;height:40px;border-radius:50%;"></div>
            <div>
              <div class="skeleton" style="height:13px;width:100px;margin-bottom:4px;"></div>
              <div class="skeleton" style="height:11px;width:70px;"></div>
            </div>
          </div>
          <div class="skeleton" style="height:12px;width:100%;margin-bottom:5px;"></div>
          <div class="skeleton" style="height:12px;width:85%;margin-bottom:5px;"></div>
          <div class="skeleton" style="height:12px;width:70%;"></div>
        </div>`,

      trending: () => `
        <div class="trending-card">
          <div class="skeleton" style="width:36px;height:36px;border-radius:6px;flex-shrink:0;"></div>
          <div style="flex:1;">
            <div class="skeleton" style="height:13px;width:90%;margin-bottom:5px;"></div>
            <div class="skeleton" style="height:13px;width:75%;margin-bottom:5px;"></div>
            <div class="skeleton" style="height:10px;width:50%;"></div>
          </div>
          <div class="skeleton" style="width:64px;height:64px;border-radius:8px;flex-shrink:0;"></div>
        </div>`,

      stat: () => `
        <div class="stats-card">
          <div class="skeleton" style="width:48px;height:48px;border-radius:12px;margin-bottom:16px;"></div>
          <div class="skeleton" style="height:32px;width:60%;margin-bottom:8px;"></div>
          <div class="skeleton" style="height:13px;width:80%;margin-bottom:10px;"></div>
          <div class="skeleton" style="height:22px;width:90px;border-radius:99px;"></div>
        </div>`,
    };

    const template = templates[type] || templates.card;
    let html = '';
    for (let i = 0; i < count; i++) {
      html += template();
    }
    container.innerHTML = html;
  };

  /**
   * Show empty state
   */
  const showEmpty = (container, title = 'Nothing here yet', description = 'No content to display.', actionHtml = '') => {
    if (!container) return;
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon"><i class="bi bi-inbox"></i></div>
        <h5 class="empty-state-title">${title}</h5>
        <p class="empty-state-description">${description}</p>
        ${actionHtml}
      </div>
    `;
  };

  /**
   * Show error state with retry
   */
  const showError = (container, message = 'Something went wrong.', retryFn = null) => {
    if (!container) return;
    const retryBtn = retryFn
      ? `<button class="btn-primary-custom" id="retryBtn"><i class="bi bi-arrow-clockwise"></i> Try Again</button>`
      : '';

    container.innerHTML = `
      <div class="error-state">
        <div class="error-state-icon"><i class="bi bi-wifi-off"></i></div>
        <h5 class="empty-state-title">Rất tiếc! Đã xảy ra lỗi</h5>
        <p class="empty-state-description">${message}</p>
        ${retryBtn}
      </div>
    `;

    if (retryFn) {
      container.querySelector('#retryBtn')?.addEventListener('click', retryFn);
    }
  };

  /**
   * Clear container
   */
  const clear = (container) => {
    if (container) container.innerHTML = '';
  };

  return { showSpinner, showSkeleton, showEmpty, showError, clear };
})();
