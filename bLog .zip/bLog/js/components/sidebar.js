/**
 * BlogHub - Sidebar Component
 * Dashboard sidebar with mobile support
 */

const Sidebar = (() => {
  const init = () => {
    setupMobileToggle();
    setupThemeToggle();
    applyRoleVisibility();
    markActiveLink();
    updateSidebarUser();
  };

  const applyRoleVisibility = () => {
    if (Storage.isAdmin()) return;
    const adminOnlyHrefs = ['dashboard.html', 'quan-ly-bai-viet.html', 'quan-ly-binh-luan.html', 'quan-ly-tags.html'];
    document.querySelectorAll('.sidebar-link[href]').forEach(link => {
      const href = link.getAttribute('href');
      if (adminOnlyHrefs.includes(href)) link.classList.add('d-none');
    });
  };

  /**
   * Mobile sidebar toggle
   */
  const setupMobileToggle = () => {
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    if (!toggleBtn || !sidebar) return;

    const open = () => {
      sidebar.classList.add('open');
      overlay?.classList.add('d-block');
      document.body.style.overflow = 'hidden';
    };

    const close = () => {
      sidebar.classList.remove('open');
      overlay?.classList.remove('d-block');
      document.body.style.overflow = '';
    };

    toggleBtn.addEventListener('click', () => {
      sidebar.classList.contains('open') ? close() : open();
    });

    overlay?.addEventListener('click', close);

    // Close on Escape
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') close();
    });
  };

  /**
   * Theme toggle in sidebar
   */
  const setupThemeToggle = () => {
    const toggle = document.getElementById('sidebarThemeToggle');
    if (!toggle) return;

    const applyTheme = (theme) => {
      document.documentElement.setAttribute('data-theme', theme);
      Storage.setTheme(theme);
      const icon = toggle.querySelector('i');
      if (icon) icon.className = theme === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
    };

    applyTheme(Storage.getTheme());
    toggle.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || 'light';
      applyTheme(current === 'dark' ? 'light' : 'dark');
    });
  };

  /**
   * Mark current page as active in sidebar
   */
  const markActiveLink = () => {
    const current = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.sidebar-link').forEach(link => {
      const href = link.getAttribute('href') || '';
      if (href === current || href.endsWith('/' + current)) {
        link.classList.add('active');
      }
    });
  };

  /**
   * Update sidebar user info
   */
  const updateSidebarUser = () => {
    const user = Storage.getUser();
    const nameEl = document.getElementById('sidebarUserName');
    const roleEl = document.getElementById('sidebarUserRole');
    const avatarEl = document.getElementById('sidebarUserAvatar');

    if (user) {
      if (nameEl) nameEl.textContent = user.name || 'Admin User';
      if (roleEl) roleEl.textContent = user.role === 'admin' ? 'Quản trị viên' : 'Người dùng';
      if (avatarEl) {
        avatarEl.style.background = 'var(--color-primary)';
        avatarEl.textContent = Helpers.getInitials(user.name || 'A');
      }
    }
  };

  /**
   * Redirect unauthenticated users
   */
  const requireAuth = () => {
    if (!Storage.isLoggedIn()) {
      window.location.href = 'dang-nhap.html?redirect=' + encodeURIComponent(window.location.href);
      return false;
    }

    if (!Storage.isAdmin()) {
      if (typeof Toast !== 'undefined') {
        Toast.warning('Không có quyền', 'Chỉ tài khoản admin mới vào được khu vực quản trị.');
      }
      setTimeout(() => {
        window.location.href = 'index.html';
      }, 800);
      return false;
    }

    return true;
  };

  return { init, markActiveLink, updateSidebarUser, requireAuth };
})();

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('sidebar')) {
    Sidebar.init();
  }
});
