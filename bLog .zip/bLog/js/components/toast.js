/**
 * BlogHub - Toast Notification Component
 */

const Toast = (() => {
  let container;

  const init = () => {
    if (document.getElementById('toastContainer')) return;
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container-custom';
    document.body.appendChild(container);
  };

  const show = (type = 'info', title, message = '', duration) => {
    init();

    const icons = {
      success: 'bi-check-circle-fill',
      error:   'bi-x-circle-fill',
      warning: 'bi-exclamation-triangle-fill',
      info:    'bi-info-circle-fill',
    };

    const dur = duration || CONSTANTS.TOAST_DURATION[type.toUpperCase()] || 3500;
    const id = Helpers.randomId('toast-');

    const toastEl = document.createElement('div');
    toastEl.id = id;
    toastEl.className = `toast-item toast-${type}`;
    toastEl.innerHTML = `
      <div class="toast-icon"><i class="bi ${icons[type] || icons.info}"></i></div>
      <div class="toast-content">
        <div class="toast-title">${title}</div>
        ${message ? `<div class="toast-message">${message}</div>` : ''}
      </div>
      <button class="toast-close" onclick="Toast.dismiss('${id}')">
        <i class="bi bi-x"></i>
      </button>
    `;

    container.appendChild(toastEl);

    // Auto dismiss
    const timer = setTimeout(() => Toast.dismiss(id), dur);
    toastEl._timer = timer;

    return id;
  };

  const dismiss = (id) => {
    const el = document.getElementById(id);
    if (!el) return;
    clearTimeout(el._timer);
    el.classList.add('exiting');
    el.addEventListener('animationend', () => el.remove(), { once: true });
    setTimeout(() => el.remove(), 400);
  };

  const success = (title, message = '', duration) => show('success', title, message, duration);
  const error   = (title, message = '', duration) => show('error',   title, message, duration);
  const warning = (title, message = '', duration) => show('warning', title, message, duration);
  const info    = (title, message = '', duration) => show('info',    title, message, duration);

  return { show, dismiss, success, error, warning, info };
})();
