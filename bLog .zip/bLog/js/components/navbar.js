/**
 * BlogHub - Navbar Component
 * Shared navbar logic for public pages
 */

const Navbar = (() => {
  const init = () => {
    setupScrollEffect();
    setupThemeToggle();
    setupScrollToTop();
    setupRevealAnimations();
    updateAuthState();
  };

  /**
   * Add "scrolled" class to navbar on scroll
   */
  const setupScrollEffect = () => {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;

    const handler = Helpers.throttle(() => {
      navbar.classList.toggle('scrolled', window.scrollY > 20);
    }, 50);

    window.addEventListener('scroll', handler, { passive: true });
  };

  /**
   * Theme toggle (dark/light mode)
   */
  const setupThemeToggle = () => {
    const toggle = document.getElementById('themeToggle');
    if (!toggle) return;

    const applyTheme = (theme) => {
      document.documentElement.setAttribute('data-theme', theme);
      Storage.setTheme(theme);
      const icon = toggle.querySelector('i');
      if (icon) {
        icon.className = theme === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
      }
    };

    // Apply saved theme
    const savedTheme = Storage.getTheme();
    applyTheme(savedTheme);

    toggle.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || 'light';
      applyTheme(current === 'dark' ? 'light' : 'dark');
    });
  };

  /**
   * Scroll to top button
   */
  const setupScrollToTop = () => {
    const btn = document.getElementById('scrollToTop');
    if (!btn) return;

    window.addEventListener('scroll', Helpers.throttle(() => {
      btn.classList.toggle('visible', window.scrollY > 400);
    }, 100), { passive: true });

    btn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  };

  /**
   * Intersection Observer for reveal animations
   */
  const setupRevealAnimations = () => {
    const elements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');
    if (!elements.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    elements.forEach(el => observer.observe(el));
  };

  /**
   * Update nav links based on auth state
   */
  const updateAuthState = () => {
    const user = Storage.getUser();
    const guestLinks = document.querySelectorAll('[data-auth="guest"]');
    const userLinks = document.querySelectorAll('[data-auth="user"]');
    const adminLinks = document.querySelectorAll('[data-auth="admin"]');
    const userNameEl = document.getElementById('navUserName');
    const avatarEl = document.getElementById('navUserAvatar');

    if (user) {
      guestLinks.forEach(el => { el.classList.remove('d-flex'); el.classList.add('d-none'); });
      userLinks.forEach(el => { el.classList.remove('d-none'); el.classList.add('d-flex'); });
      if (Storage.isAdmin()) {
        adminLinks.forEach(el => { el.classList.remove('d-none'); el.classList.add('d-flex'); });
      }
      if (userNameEl) userNameEl.textContent = user.name || 'User';
      if (avatarEl) avatarEl.src = user.avatar || Helpers.getAvatarUrl(user.name);
    } else {
      guestLinks.forEach(el => { el.classList.remove('d-none'); el.classList.add('d-flex'); });
      userLinks.forEach(el => { el.classList.remove('d-flex'); el.classList.add('d-none'); });
      adminLinks.forEach(el => { el.classList.remove('d-flex'); el.classList.add('d-none'); });
    }
  };

  /**
   * Logout
   */
  const logout = () => {
    Storage.removeUser();
    Toast.success('Đã đăng xuất', 'Hẹn gặp lại bạn.');
    setTimeout(() => window.location.href = 'index.html', 1200);
  };

  // Expose logout globally for inline onclick
  window.BlogHubLogout = logout;

  return { init, updateAuthState, logout };
})();

// Init navbar on DOM ready
document.addEventListener('DOMContentLoaded', Navbar.init);
