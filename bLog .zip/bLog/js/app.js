/**
 * BlogHub - App Bootstrap
 * Global initialization and shared setup
 */

const App = (() => {
  const VERSION = '1.0.0';

  const init = () => {
    applyTheme();
    normalizeLegacyAdminSession();
    setupGlobalEventListeners();
    guardAdminPages();
    console.log(`%cBlogHub v${VERSION}`, 'color:#2563EB;font-weight:700;font-size:16px;');
  };

  const normalizeLegacyAdminSession = () => {
    const user = Storage.getUser();
    if (!user || user.role !== 'admin') return;
    if (Storage.isAdmin()) return;
    Storage.setUser({ ...user, role: 'user' });
  };

  /**
   * Apply saved theme on load (before rendering)
   */
  const applyTheme = () => {
    const theme = Storage.getTheme();
    if (theme === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
    }
  };

  /**
   * Setup global event listeners
   */
  const setupGlobalEventListeners = () => {
    // Global error handler
    window.addEventListener('unhandledrejection', (event) => {
      console.error('Unhandled promise rejection:', event.reason);
    });

    // Active nav link highlighting
    highlightActiveNav();
  };

  /**
   * Highlight the active nav link based on current page
   */
  const highlightActiveNav = () => {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-link').forEach(link => {
      const href = link.getAttribute('href') || '';
      if (href === currentPage || (currentPage === '' && href === 'index.html')) {
        link.classList.add('active');
      }
    });
  };

  /**
   * Protect admin pages from unauthenticated or non-admin users
   */
  const guardAdminPages = () => {
    const adminPages = ['dashboard.html', 'quan-ly-bai-viet.html', 'quan-ly-binh-luan.html', 'quan-ly-tags.html'];
    const currentPage = window.location.pathname.split('/').pop();
    if (!adminPages.includes(currentPage)) return;

    if (!Storage.isLoggedIn()) {
      window.location.href = `dang-nhap.html?redirect=${encodeURIComponent(window.location.href)}`;
      return;
    }

    if (!Storage.isAdmin()) {
      window.location.href = 'index.html';
    }
  };

  return { init, VERSION };
})();

// Initialize app on DOM ready
document.addEventListener('DOMContentLoaded', App.init);
