/**
 * BlogHub - Dashboard Page Script
 */

let dashboardData = { posts: [], comments: [], tags: [] };

const initDashboard = async () => {
  if (!Sidebar.requireAuth()) return;

  await Promise.all([
    loadDashboardStats(),
    loadRecentPosts(),
    loadRecentComments(),
    loadTagProgress(),
  ]);

  renderActivityChart();
  renderDonutChart();
  animateStats();
};

// ── Stats ──
const loadDashboardStats = async () => {
  try {
    const [posts, comments, tags] = await Promise.all([
      PostsAPI.getAll({ limit: 100 }),
      CommentsAPI.getAll({ limit: 100 }),
      TagsAPI.getAll(),
    ]);

    dashboardData.posts = Array.isArray(posts) ? posts : [];
    dashboardData.comments = Array.isArray(comments) ? comments : [];
    dashboardData.tags = Array.isArray(tags) ? tags : [];

    const published = dashboardData.posts.filter(p => p.status === 'published').length;
    const pending = dashboardData.comments.filter(c => c.status === 'pending').length;
    const totalViews = dashboardData.posts.reduce((sum, p) => sum + (p.views || 0), 0);
    const totalLikes = dashboardData.posts.reduce((sum, p) => sum + (p.likes || 0), 0);

    updateStat('statTotalPosts', dashboardData.posts.length);
    updateStat('statPublished', published);
    updateStat('statComments', dashboardData.comments.length);
    updateStat('statPending', pending);
    updateStat('statViews', Formatters.formatNumber(totalViews));
    updateStat('statLikes', Formatters.formatNumber(totalLikes));
    updateStat('statTags', dashboardData.tags.length);
    updateStat('statDrafts', dashboardData.posts.filter(p => p.status === 'draft').length);

  } catch (err) {
    // Use demo data
    updateStat('statTotalPosts', 24);
    updateStat('statPublished', 18);
    updateStat('statComments', 156);
    updateStat('statPending', 7);
    updateStat('statViews', '12.4k');
    updateStat('statLikes', '3.2k');
    updateStat('statTags', 12);
    updateStat('statDrafts', 6);
  }
};

const updateStat = (id, value) => {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
};

// ── Animate stats numbers ──
const animateStats = () => {
  document.querySelectorAll('.stats-value[data-target]').forEach(el => {
    const target = parseInt(el.dataset.target, 10);
    if (isNaN(target)) return;

    let current = 0;
    const step = Math.ceil(target / 50);
    const interval = setInterval(() => {
      current = Math.min(current + step, target);
      el.textContent = Formatters.formatNumber(current);
      if (current >= target) clearInterval(interval);
    }, 20);
  });
};

// ── Recent Posts ──
const loadRecentPosts = async () => {
  const tbody = document.getElementById('recentPostsTbody');
  if (!tbody) return;

  try {
    const posts = await PostsAPI.getLatest(5);
    const list = Array.isArray(posts) ? posts : [];

    if (!list.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4" style="color:var(--text-tertiary);">Chưa có bài viết</td></tr>';
      return;
    }

    tbody.innerHTML = list.map(post => `
      <tr>
        <td>
          <a href="bai-viet.html?id=${post.id}" class="post-title-cell" style="text-decoration:none;">
            ${post.title}
          </a>
        </td>
        <td>${Formatters.statusBadge(post.status)}</td>
        <td style="font-size:0.8125rem;color:var(--text-secondary);">${Formatters.formatDate(post.createdAt)}</td>
        <td style="font-size:0.8125rem;color:var(--text-secondary);">
          <i class="bi bi-eye"></i> ${Formatters.formatNumber(post.views || 0)}
        </td>
        <td>
          <a href="bai-viet.html?id=${post.id}" class="action-btn view" title="View"><i class="bi bi-eye"></i></a>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4" style="color:var(--color-accent-red);">Không thể tải bài viết</td></tr>';
  }
};

// ── Recent Comments ──
const loadRecentComments = async () => {
  const container = document.getElementById('recentComments');
  if (!container) return;

  try {
    const comments = await CommentsAPI.getRecent(5);
    const list = Array.isArray(comments) ? comments : [];

    if (!list.length) {
      container.innerHTML = '<p style="color:var(--text-tertiary);font-size:0.875rem;text-align:center;padding:1rem;">Chưa có bình luận nào</p>';
      return;
    }

    container.innerHTML = list.map(c => `
      <div class="recent-comment-item">
        <img src="${Helpers.getAvatarUrl(c.name || 'User')}" alt="${c.name}" class="avatar avatar-sm" style="flex-shrink:0;">
        <div style="flex:1;min-width:0;">
          <div style="font-size:0.8125rem;font-weight:600;color:var(--text-primary);">${c.name || 'Anonymous'}</div>
          <div class="recent-comment-text">${c.content || c.text || ''}</div>
          <div style="font-size:0.6875rem;color:var(--text-tertiary);margin-top:0.25rem;">${Formatters.timeAgo(c.createdAt)}</div>
        </div>
        ${Formatters.commentStatusBadge(c.status)}
      </div>
    `).join('');
  } catch (err) {
    container.innerHTML = '';
  }
};

// ── Tag Progress ──
const loadTagProgress = async () => {
  const container = document.getElementById('tagProgress');
  if (!container) return;

  const demoTags = [
    { name: 'JavaScript', postCount: 42 },
    { name: 'CSS & Design', postCount: 31 },
    { name: 'Python', postCount: 27 },
    { name: 'React', postCount: 24 },
    { name: 'Node.js', postCount: 18 },
  ];

  try {
    const tags = await TagsAPI.getPopular(5);
    const list = (Array.isArray(tags) && tags.length) ? tags : demoTags;
    const max = Math.max(...list.map(t => t.postCount || 0), 1);

    container.innerHTML = list.map(tag => `
      <div class="tag-progress-item">
        <div class="tag-progress-header">
          <span class="tag-progress-name">${tag.name}</span>
          <span class="tag-progress-count">${tag.postCount || 0} posts</span>
        </div>
        <div class="tag-progress-bar">
          <div class="tag-progress-fill" style="width:${((tag.postCount || 0) / max * 100).toFixed(1)}%"></div>
        </div>
      </div>
    `).join('');
  } catch (err) {
    container.innerHTML = demoTags.slice(0, 3).map(tag => `
      <div class="tag-progress-item">
        <div class="tag-progress-header">
          <span class="tag-progress-name">${tag.name}</span>
          <span class="tag-progress-count">${tag.postCount} posts</span>
        </div>
        <div class="tag-progress-bar">
          <div class="tag-progress-fill" style="width:${tag.postCount}%;"></div>
        </div>
      </div>
    `).join('');
  }
};

// ── Activity Chart ──
const renderActivityChart = () => {
  const container = document.getElementById('activityChart');
  if (!container) return;

  const months = CONSTANTS.CHART_MONTHS.slice(0, 7);
  const viewsData = [30, 55, 40, 70, 45, 85, 65];
  const likesData = [15, 30, 22, 45, 28, 60, 42];

  const maxVal = Math.max(...viewsData, ...likesData);

  container.innerHTML = months.map((month, i) => {
    const vH = ((viewsData[i] / maxVal) * 100).toFixed(1);
    const lH = ((likesData[i] / maxVal) * 100).toFixed(1);

    return `
      <div class="activity-bar-group">
        <div style="display:flex;align-items:flex-end;gap:2px;flex:1;height:100%;">
          <div class="activity-bar activity-bar-views" 
               style="height:${vH}%;flex:1;"
               title="${month}: ${viewsData[i]} views">
          </div>
          <div class="activity-bar activity-bar-likes" 
               style="height:${lH}%;flex:1;"
               title="${month}: ${likesData[i]} likes">
          </div>
        </div>
        <div class="chart-label">${month}</div>
      </div>
    `;
  }).join('');
};

// ── Donut Chart ──
const renderDonutChart = () => {
  const canvas = document.getElementById('donutChart');
  if (!canvas) return;

  // Pure CSS donut
  const published = 65;
  const draft = 20;
  const archived = 15;

  canvas.style.setProperty('--p1', `${published}%`);
  canvas.style.setProperty('--p2', `${published + draft}%`);
  canvas.style.setProperty('--p3', `${published + draft + archived}%`);
};

document.addEventListener('DOMContentLoaded', initDashboard);
