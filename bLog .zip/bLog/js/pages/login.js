/**
 * BlogHub - Login Page Script
 */

const initLogin = () => {
  // Redirect if already logged in
  if (Storage.isLoggedIn()) {
    window.location.href = Storage.isAdmin() ? 'dashboard.html' : 'index.html';
    return;
  }

  setupForm();
  setupRegisterForm();
  setupAuthModeToggle();
  setupPasswordToggle();
  setupRememberMe();
};

const setupForm = () => {
  const form = document.getElementById('loginForm');
  if (!form) return;

  // Real-time email validation
  const emailInput = document.getElementById('loginEmail');
  emailInput?.addEventListener('blur', () => {
    const error = Validators.isEmail(emailInput.value);
    if (error) {
      emailInput.classList.add('is-invalid');
    } else {
      Validators.markValid('loginEmail');
    }
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    Validators.clearForm(form);

    const data = {
      email: document.getElementById('loginEmail')?.value?.trim(),
      password: document.getElementById('loginPassword')?.value,
    };

    const errors = Validators.validateLoginForm(data);
    if (Validators.hasErrors(errors)) {
      Validators.displayErrors(errors);
      return;
    }

    const submitBtn = form.querySelector('[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.innerHTML = `
      <span class="spinner-custom" style="width:18px;height:18px;border-width:2px;border-color:rgba(255,255,255,0.3);border-top-color:white;"></span>
      Signing in...
      Đang đăng nhập...
    `;

    try {
      const user = await UsersAPI.login(data);
      Storage.setUser(user);
      const rememberMe = document.getElementById('rememberMe')?.checked;
      if (rememberMe) {
        Storage.set(CONSTANTS.STORAGE_KEYS.REMEMBER_ME, { email: data.email });
      }

      Toast.success('Chào mừng trở lại!', 'Đang đăng nhập...');

      const redirect = Helpers.getQueryParam('redirect');
      setTimeout(() => {
        window.location.href = Storage.isAdmin() ? (redirect || 'dashboard.html') : 'index.html';
      }, 1000);

    } catch (err) {
      showAuthError(err.message || 'Email hoặc mật khẩu không đúng.');
      submitBtn.disabled = false;
      submitBtn.innerHTML = `<i class="bi bi-box-arrow-in-right"></i> Đăng nhập`;
    }
  });
};

const setupRegisterForm = () => {
  const form = document.getElementById('registerForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    Validators.clearForm(form);

    const data = {
      name: document.getElementById('registerName')?.value?.trim(),
      email: document.getElementById('registerEmail')?.value?.trim(),
      password: document.getElementById('registerPassword')?.value,
      confirmPassword: document.getElementById('registerConfirmPassword')?.value,
    };

    const errors = Validators.validateRegisterForm(data);
    if (Validators.hasErrors(errors)) {
      Validators.displayErrors(errors);
      return;
    }

    const submitBtn = document.getElementById('registerSubmitBtn');
    submitBtn.disabled = true;
    submitBtn.innerHTML = `
      <span class="spinner-custom" style="width:18px;height:18px;border-width:2px;border-color:rgba(255,255,255,0.3);border-top-color:white;"></span>
      Đang đăng ký...
    `;

    try {
      const user = await UsersAPI.register(data);
      Storage.setUser(user);
      Toast.success('Đăng ký thành công!', 'Tài khoản đã được lưu vào MockAPI.');
      setTimeout(() => {
        window.location.href = 'index.html';
      }, 1000);
    } catch (err) {
      showAuthError(err.message || 'Không thể đăng ký. Kiểm tra lại bảng users trên MockAPI.');
      submitBtn.disabled = false;
      submitBtn.innerHTML = `<i class="bi bi-person-plus"></i> Đăng ký`;
    }
  });
};

const setupAuthModeToggle = () => {
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  const loginSwitch = document.getElementById('loginSwitch');
  const registerSwitch = document.getElementById('registerSwitch');
  const title = document.getElementById('authTitle');
  const subtitle = document.getElementById('authSubtitle');

  const showRegister = (event) => {
    event?.preventDefault();
    loginForm?.classList.add('d-none');
    registerForm?.classList.remove('d-none');
    loginSwitch?.classList.add('d-none');
    registerSwitch?.classList.remove('d-none');
    if (title) title.textContent = 'Đăng ký tài khoản';
    if (subtitle) subtitle.textContent = 'Tạo tài khoản mới và lưu trực tiếp vào MockAPI.';
    clearAuthError();
  };

  const showLogin = (event) => {
    event?.preventDefault();
    registerForm?.classList.add('d-none');
    loginForm?.classList.remove('d-none');
    registerSwitch?.classList.add('d-none');
    loginSwitch?.classList.remove('d-none');
    if (title) title.textContent = 'Đăng nhập tài khoản';
    if (subtitle) subtitle.textContent = 'Nhập email và mật khẩu đã có trong bảng users.';
    clearAuthError();
  };

  document.getElementById('showRegisterLink')?.addEventListener('click', showRegister);
  document.getElementById('showLoginLink')?.addEventListener('click', showLogin);
};

const showAuthError = (message) => {
  let alertEl = document.getElementById('authAlert');
  if (!alertEl) {
    alertEl = document.createElement('div');
    alertEl.id = 'authAlert';
    document.getElementById('authAlertContainer')?.appendChild(alertEl);
  }
  alertEl.className = 'auth-alert auth-alert-error';
  alertEl.innerHTML = `<i class="bi bi-exclamation-circle-fill"></i> ${message}`;
};

const clearAuthError = () => {
  document.getElementById('authAlert')?.remove();
};

const setupPasswordToggle = () => {
  const toggle = document.getElementById('passwordToggle');
  const input = document.getElementById('loginPassword');

  if (toggle && input) {
    toggle.addEventListener('click', () => togglePasswordInput(input, toggle));
  }

  document.querySelectorAll('[data-password-toggle]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = document.getElementById(btn.dataset.passwordToggle);
      if (target) togglePasswordInput(target, btn);
    });
  });
};

const togglePasswordInput = (input, button) => {
  const isPassword = input.type === 'password';
  input.type = isPassword ? 'text' : 'password';
  button.querySelector('i').className = isPassword ? 'bi bi-eye-slash' : 'bi bi-eye';
};

const setupRememberMe = () => {
  const remembered = Storage.get(CONSTANTS.STORAGE_KEYS.REMEMBER_ME);
  if (remembered?.email) {
    const emailInput = document.getElementById('loginEmail');
    const checkbox = document.getElementById('rememberMe');
    if (emailInput) emailInput.value = remembered.email;
    if (checkbox) checkbox.checked = true;
  }
};

document.addEventListener('DOMContentLoaded', initLogin);
