/**
 * BlogHub - Manage Posts Page Script
 */

let allPosts = [];
let filteredPosts = [];
let currentPage = 1;
const PER_PAGE = CONSTANTS.TABLE_PER_PAGE;
let editingPostId = null;

const initManagePosts = async () => {
  if (!Sidebar.requireAuth()) return;
  await loadAllPosts();
  setupSearchFilter();
  setupStatusFilter();
  setupAddPostModal();
  setupEditPostModal();
};

const loadAllPosts = async () => {
  const tbody = document.getElementById('postsTbody');
  if (!tbody) return;

  const tableBody = tbody.closest('table')?.querySelector('tbody') || tbody;
  Loader.showSkeleton(tableBody, 5, 'row');

  try {
    const posts = await PostsAPI.getAll({ limit: 100 });
    allPosts = Array.isArray(posts) ? posts : [];
    filteredPosts = [...allPosts];
    renderTable();
    updateCounts();
  } catch (err) {
    Loader.showError(tableBody, err.message, loadAllPosts);
  }
};

const renderTable = () => {
  const tbody = document.getElementById('postsTbody');
  if (!tbody) return;

  const total = Pagination.totalPages(filteredPosts.length, PER_PAGE);
  const page = Pagination.paginate(filteredPosts, currentPage, PER_PAGE);

  if (!page.length) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center py-5"><div class="empty-state" style="padding:2rem 0;"><div class="empty-state-icon"><i class="bi bi-inbox"></i></div><div class="empty-state-title">Không tìm thấy bài viết nào</div></div></td></tr>`;
    document.getElementById('postsPagination').innerHTML = '';
    return;
  }

  tbody.innerHTML = page.map(p => Cards.postTableRow(p)).join('');

  const paginationEl = document.getElementById('postsPagination');
  if (paginationEl) {
    Pagination.render(paginationEl, currentPage, total, (pg) => {
      currentPage = pg;
      renderTable();
    });
  }
};

const updateCounts = () => {
  const total = document.getElementById('totalPostsCount');
  const published = document.getElementById('publishedCount');
  const drafts = document.getElementById('draftsCount');
  if (total) total.textContent = allPosts.length;
  if (published) published.textContent = allPosts.filter(p => p.status === 'published').length;
  if (drafts) drafts.textContent = allPosts.filter(p => p.status === 'draft').length;
};

const setupSearchFilter = () => {
  const searchInput = document.getElementById('postsSearch');
  if (!searchInput) return;

  searchInput.addEventListener('input', Helpers.debounce((e) => {
    const query = e.target.value.toLowerCase().trim();
    filteredPosts = query
      ? allPosts.filter(p => p.title.toLowerCase().includes(query) || (p.excerpt || '').toLowerCase().includes(query))
      : [...allPosts];
    currentPage = 1;
    renderTable();
  }, CONSTANTS.SEARCH_DEBOUNCE_MS));
};

const setupStatusFilter = () => {
  document.querySelectorAll('[data-status-filter]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-status-filter]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const status = btn.dataset.statusFilter;
      filteredPosts = status === 'all' ? [...allPosts] : allPosts.filter(p => p.status === status);
      currentPage = 1;
      renderTable();
    });
  });
};

// ── CRUD ──

// Global confirm delete (called from card)
window.confirmDelete = (id, title) => {
  Modal.confirm({
    title: 'Xóa bài viết',
    message: `Bạn có chắc chắn muốn xóa "<strong>${title}</strong>"? Hành động này không thể hoàn tác.`,
    confirmText: 'Xóa',
    cancelText: 'Hủy',
    type: 'danger',
    onConfirm: () => deletePost(id),
  });
};

const deletePost = async (id) => {
  try {
    await PostsAPI.remove(id);
    allPosts = allPosts.filter(p => p.id != id);
    filteredPosts = filteredPosts.filter(p => p.id != id);

    // jQuery animate row removal
    const row = document.querySelector(`tr[data-id="${id}"]`);
    if (row) {
      $(row).animate({ opacity: 0, height: 0 }, 300, () => { row.remove(); renderTable(); });
    } else {
      renderTable();
    }

    updateCounts();
    Toast.success('Đã xóa!', 'Bài viết đã được xóa thành công.');
  } catch (err) {
    Toast.error('Lỗi', 'Không thể xóa bài viết: ' + err.message);
  }
};

// Open Edit Modal
window.openEditModal = async (id) => {
  editingPostId = id;
  const post = allPosts.find(p => p.id == id);
  if (!post) return;

  document.getElementById('editTitle').value = post.title || '';
  document.getElementById('editExcerpt').value = post.excerpt || '';
  document.getElementById('editStatus').value = post.status || 'published';
  document.getElementById('editImage').value = post.image || '';
  document.getElementById('editTags').value = Array.isArray(post.tags) ? post.tags.join(', ') : '';

  Modal.show('editPostModal');
};

const setupEditPostModal = () => {
  const form = document.getElementById('editPostForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!editingPostId) return;

    const data = {
      title: document.getElementById('editTitle').value.trim(),
      excerpt: document.getElementById('editExcerpt').value.trim(),
      status: document.getElementById('editStatus').value,
      image: document.getElementById('editImage').value.trim(),
      tags: document.getElementById('editTags').value.split(',').map(t => t.trim()).filter(Boolean),
    };

    const errors = Validators.validatePostForm(data);
    if (Validators.hasErrors(errors)) {
      Validators.displayErrors(errors);
      return;
    }

    const btn = form.querySelector('[type="submit"]');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-custom" style="width:16px;height:16px;border-width:2px;"></span> Saving...';

    try {
      const updated = await PostsAPI.update(editingPostId, data);
      const idx = allPosts.findIndex(p => p.id == editingPostId);
      if (idx > -1) allPosts[idx] = { ...allPosts[idx], ...data };
      filteredPosts = [...allPosts];
      renderTable();
      Modal.hide('editPostModal');
      Toast.success('Đã cập nhật!', 'Bài viết được cập nhật thành công.');
    } catch (err) {
      Toast.error('Lỗi', err.message);
    } finally {
      btn.disabled = false;
      btn.innerHTML = 'Lưu thay đổi';
    }
  });
};

// Add post modal
const setupAddPostModal = () => {
  const addBtn = document.getElementById('addPostBtn');
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      window.location.href = 'dang-bai.html';
    });
  }
};

document.addEventListener('DOMContentLoaded', initManagePosts);
