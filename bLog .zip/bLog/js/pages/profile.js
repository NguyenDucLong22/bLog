/**
 * BlogHub - Profile Page Script
 */

let profileUser = null;
let userPosts = [];

const initProfile = async () => {
  const user = Storage.getUser();
  if (!user) {
    window.location.href = 'dang-nhap.html';
    return;
  }

  profileUser = user;
  renderProfileHeader(user);
  renderProfileOverview(user);
  renderAchievements([]);
  await loadUserPosts(user);
  loadActivityTimeline();
  setupProfileTabs();
  setupEditProfileModal(user);
};

const getRoleLabel = (user) => Storage.isAdmin() ? 'Quản trị viên' : 'Thành viên';

const setText = (id, value) => {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
};

const renderProfileHeader = (user) => {
  const name = user.name || user.email?.split('@')[0] || 'Người dùng BlogHub';
  const bio = user.bio || (Storage.isAdmin()
    ? 'Quản lý nội dung, theo dõi bài viết và giữ nhịp xuất bản cho BlogHub.'
    : 'Tác giả BlogHub. Viết bài, chỉnh hồ sơ và theo dõi hoạt động cá nhân.');

  setText('profileName', name);
  setText('profileBio', bio);
  setText('profileEmail', user.email || '');
  setText('profileJoined', `Tham gia ${Formatters.formatDate(user.createdAt || new Date().toISOString())}`);
  setText('profileRoleText', getRoleLabel(user));
  setText('profileRoleBadge', getRoleLabel(user));
  setText('aboutBio', bio);
  setText('aboutEmail', user.email || '');
  setText('aboutRole', getRoleLabel(user));
  setText('aboutRoleCard', getRoleLabel(user));
  setText('aboutStatus', Storage.isAdmin() ? 'Có quyền quản trị nội dung' : 'Tài khoản người đọc');

  const avatarEl = document.getElementById('profileAvatar');
  if (avatarEl) {
    avatarEl.src = user.avatar || Helpers.getAvatarUrl(name, 128);
    avatarEl.onerror = () => { avatarEl.src = Helpers.getAvatarUrl(name, 128); };
  }
};

const renderProfileOverview = (user) => {
  const isAdmin = Storage.isAdmin();
  setText('profileSummary', isAdmin
    ? 'Bạn đang dùng tài khoản admin. Các lối tắt quản trị, đăng bài và dashboard sẽ hiện ở đây để thao tác nhanh hơn.'
    : 'Đây là không gian cá nhân của bạn trên BlogHub. Bạn có thể viết bài mới, chỉnh hồ sơ và theo dõi nội dung của mình.');

  const chips = [
    { icon: 'bi-shield-check', label: getRoleLabel(user) },
    { icon: 'bi-envelope-check', label: user.email || 'Chưa có email' },
    { icon: 'bi-palette', label: Storage.getTheme() === 'dark' ? 'Giao diện tối' : 'Giao diện sáng' },
  ];

  const chipContainer = document.getElementById('profileChips');
  if (chipContainer) {
    chipContainer.innerHTML = chips.map(chip => `
      <span class="profile-chip"><i class="bi ${chip.icon}"></i>${chip.label}</span>
    `).join('');
  }
};

const updateStats = (posts = []) => {
  const totalViews = posts.reduce((sum, p) => sum + Number(p.views || 0), 0);
  const totalLikes = posts.reduce((sum, p) => sum + Number(p.likes || 0), 0);

  setText('statPostCount', posts.length);
  setText('statViewCount', Formatters.formatNumber(totalViews));
  setText('statLikeCount', Formatters.formatNumber(totalLikes));
  setText('statPostCount2', posts.length);
  setText('statViewCount2', Formatters.formatNumber(totalViews));
  setText('statLikeCount2', Formatters.formatNumber(totalLikes));
  renderAchievements(posts);
};

const normalizeIdentity = (value) => String(value || '').trim().toLowerCase();

const isPostOwnedByUser = (post, user) => {
  const userId = normalizeIdentity(user.id);
  const userName = normalizeIdentity(user.name);
  const userEmail = normalizeIdentity(user.email);
  const userAlias = userEmail.split('@')[0];

  const postAuthorId = normalizeIdentity(post.authorId || post.userId || post.createdById);
  const postAuthorEmail = normalizeIdentity(post.authorEmail || post.email || post.userEmail || post.createdByEmail);
  const postAuthor = normalizeIdentity(post.author || post.username || post.name || post.createdBy);

  return (
    (userId && postAuthorId === userId) ||
    (userEmail && postAuthorEmail === userEmail) ||
    (userName && postAuthor === userName) ||
    (userEmail && postAuthor === userEmail) ||
    (userAlias && postAuthor === userAlias)
  );
};

const loadUserPosts = async (user) => {
  const container = document.getElementById('userPosts');
  if (!container) return;

  Loader.showSkeleton(container, 3, 'card');

  try {
    const posts = await PostsAPI.getAll({ limit: 100 });
    userPosts = Array.isArray(posts)
      ? posts
        .filter(p => isPostOwnedByUser(p, user))
        .sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))
      : [];
    setText('aboutPostSync', 'Đã kết nối');
    updateStats(userPosts);
    renderPostsState(container, userPosts);
  } catch (err) {
    userPosts = [];
    setText('aboutPostSync', 'Chưa kết nối');
    updateStats([]);
    renderOfflineProfileState(container);
  }
};

const renderPostsState = (container, posts) => {
  const hint = document.getElementById('postsSectionHint');

  if (!posts.length) {
    if (hint) hint.textContent = Storage.isAdmin()
      ? 'Chưa có bài viết nào trên MockAPI posts.'
      : 'Tài khoản này chưa có bài viết riêng.';

    container.innerHTML = `
      <div class="profile-empty-card">
        <div class="profile-empty-icon"><i class="bi bi-journal-text"></i></div>
        <h4>${Storage.isAdmin() ? 'Chưa có bài viết để quản lý' : 'Không có bài viết riêng'}</h4>
        <p>${Storage.isAdmin()
          ? 'Tạo bài đầu tiên để nội dung xuất hiện ở trang chủ và dashboard.'
          : 'Bắt đầu bằng một bài viết đầu tiên. Bài của bạn sẽ được lưu trực tiếp vào MockAPI posts.'}</p>
        <div class="profile-empty-actions">
          <a href="index.html#postsSection" class="btn-outline-custom"><i class="bi bi-grid"></i> Xem bài viết</a>
          <a href="dang-bai.html" class="btn-primary-custom"><i class="bi bi-plus"></i> Tạo bài</a>
        </div>
      </div>
    `;
    return;
  }

  if (hint) hint.textContent = 'Những bài viết do tài khoản hiện tại đăng.';

  container.innerHTML = `<div class="posts-grid profile-posts-grid">${posts.map(p => Cards.postCard(p)).join('')}</div>`;
  container.querySelectorAll('.reveal').forEach(el => el.classList.add('revealed'));
};

const renderOfflineProfileState = (container) => {
  container.innerHTML = `
    <div class="profile-empty-card is-soft">
      <div class="profile-empty-icon"><i class="bi bi-wifi-off"></i></div>
      <h4>Chưa tải được dữ liệu bài viết</h4>
      <p>MockAPI có thể chưa tạo resource posts hoặc mạng đang chậm. Hồ sơ vẫn dùng được bình thường.</p>
      <button class="btn-primary-custom" onclick="loadUserPosts(profileUser)"><i class="bi bi-arrow-clockwise"></i> Tải lại</button>
    </div>
  `;
};

const loadActivityTimeline = () => {
  const container = document.getElementById('activityTimeline');
  if (!container) return;

  const latestPost = userPosts[0];
  const activities = [
    latestPost
      ? { icon: 'bi-file-earmark-text', label: `Có bài viết "${latestPost.title || 'Không tiêu đề'}"`, time: Formatters.timeAgo(latestPost.createdAt), active: true }
      : { icon: 'bi-person-check', label: 'Hồ sơ đã sẵn sàng', time: 'Vừa xong', active: true },
    { icon: 'bi-shield-check', label: `${getRoleLabel(profileUser)} đang đăng nhập`, time: 'Phiên hiện tại', active: false },
    { icon: 'bi-palette', label: `Đang dùng ${Storage.getTheme() === 'dark' ? 'giao diện tối' : 'giao diện sáng'}`, time: 'Tùy chỉnh cá nhân', active: false },
  ];

  container.innerHTML = `
    <div class="timeline">
      ${activities.map(a => `
        <div class="timeline-item">
          <div class="timeline-dot ${a.active ? 'active' : ''}">
            <i class="bi ${a.icon}"></i>
          </div>
          <div class="timeline-content">
            <div class="timeline-title">${a.label}</div>
            <div class="timeline-time">${a.time || 'Không rõ thời gian'}</div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
};

const renderAchievements = (posts) => {
  const container = document.getElementById('profileAchievements');
  if (!container) return;

  const totalViews = posts.reduce((sum, p) => sum + Number(p.views || 0), 0);
  const items = [
    { icon: 'bi-person-badge', label: Storage.isAdmin() ? 'Admin nội dung' : 'Thành viên mới', unlocked: true },
    { icon: 'bi-journal-check', label: 'Có bài viết đầu tiên', unlocked: posts.length > 0 },
    { icon: 'bi-eye', label: 'Đạt 100 lượt xem', unlocked: totalViews >= 100 },
  ];

  container.innerHTML = items.map(item => `
    <div class="achievement-item ${item.unlocked ? 'unlocked' : ''}">
      <i class="bi ${item.icon}"></i>
      <span>${item.label}</span>
    </div>
  `).join('');
};

const setupProfileTabs = () => {
  document.querySelectorAll('.profile-nav-tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      e.preventDefault();
      document.querySelectorAll('.profile-nav-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const target = tab.dataset.tab;
      document.querySelectorAll('.profile-tab-content').forEach(el => el.classList.add('d-none'));
      document.getElementById(`tab-${target}`)?.classList.remove('d-none');
    });
  });
};

const setupEditProfileModal = (user) => {
  const form = document.getElementById('editProfileForm');
  if (!form) return;

  const nameInput = document.getElementById('editName');
  const bioInput = document.getElementById('editBio');
  const avatarInput = document.getElementById('editAvatar');

  if (nameInput) nameInput.value = user.name || '';
  if (bioInput) bioInput.value = user.bio || '';
  if (avatarInput) avatarInput.value = user.avatar || '';

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const updates = {
      name: nameInput?.value?.trim() || user.name,
      bio: bioInput?.value?.trim() || '',
      avatar: avatarInput?.value?.trim() || user.avatar,
    };

    const btn = form.querySelector('[type="submit"]');
    btn.disabled = true;

    try {
      const updatedUser = { ...Storage.getUser(), ...updates };
      Storage.setUser(updatedUser);
      profileUser = updatedUser;
      renderProfileHeader(updatedUser);
      renderProfileOverview(updatedUser);
      Modal.hide('editProfileModal');
      Toast.success('Đã cập nhật!', 'Hồ sơ của bạn đã được lưu lại.');
    } catch (err) {
      Toast.error('Lỗi', err.message);
    } finally {
      btn.disabled = false;
    }
  });
};

document.addEventListener('DOMContentLoaded', initProfile);
