/**
 * BlogHub - Create Post Page Script
 */

let selectedTags = [];
let availableTags = [];
let isPreviewMode = false;
let draftTimer = null;

const initCreatePost = async () => {
  if (!Storage.isLoggedIn()) {
    window.location.href = 'dang-nhap.html?redirect=' + encodeURIComponent(window.location.href);
    return;
  }
  await loadAvailableTags();
  setupTitleInput();
  setupContentTextarea();
  setupTagsSelector();
  setupThumbnail();
  setupPreviewToggle();
  setupPublishForm();
  loadDraft();
};

// ── Tags ──
const loadAvailableTags = async () => {
  try {
    const tags = await TagsAPI.getAll();
    availableTags = Array.isArray(tags) ? tags.map(t => t.name) : [];
  } catch (err) {
    availableTags = ['JavaScript', 'CSS', 'HTML', 'Design', 'React', 'Python', 'UX', 'Business', 'Tools'];
  }
};

const normalizeTagName = (name) => `${name || ''}`.trim().replace(/\s+/g, ' ');

const tagExists = (name) => availableTags.some(t => t.toLowerCase() === name.toLowerCase());

const saveTagIfNeeded = async (name) => {
  const tagName = normalizeTagName(name);
  if (!tagName || tagExists(tagName)) return;

  try {
    const savedTag = await TagsAPI.create({
      name: tagName,
      color: 'purple',
      description: '',
    });
    availableTags.push(savedTag?.name || tagName);
  } catch (err) {
    console.warn('Could not save tag to MockAPI:', err.message);
  }
};

const syncSelectedTagsToApi = async () => {
  await Promise.all(selectedTags.map(saveTagIfNeeded));
};

const collectPendingTagInput = () => {
  const input = document.getElementById('tagsInput');
  const tagName = normalizeTagName(input?.value);
  if (tagName && !selectedTags.includes(tagName) && selectedTags.length < 5) {
    selectedTags.push(tagName);
    renderSelectedTags();
  }
  if (input) input.value = '';
};

const setupTagsSelector = () => {
  const input = document.getElementById('tagsInput');
  const dropdown = document.getElementById('tagsDropdown');
  if (!input) return;

  input.addEventListener('input', () => {
    const query = input.value.toLowerCase();
    if (!query) { if (dropdown) dropdown.innerHTML = ''; return; }

    const matches = availableTags.filter(t =>
      t.toLowerCase().includes(query) && !selectedTags.includes(t)
    );

    if (dropdown) {
      dropdown.innerHTML = matches.length
        ? matches.map(t => `<div class="tags-dropdown-item" onclick="addTag('${t}')">${t}</div>`).join('')
        : `<div class="tags-dropdown-item" style="color:var(--text-tertiary);">Press Enter to add "${input.value}"</div>`;
    }
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const val = input.value.trim();
      if (val) addTag(val);
    }
    if (e.key === 'Backspace' && !input.value && selectedTags.length) {
      removeTag(selectedTags[selectedTags.length - 1]);
    }
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('#tagsSelector')) {
      if (dropdown) dropdown.innerHTML = '';
    }
  });
};

window.addTag = async (name) => {
  const tagName = normalizeTagName(name);
  if (!tagName || selectedTags.includes(tagName) || selectedTags.length >= 5) return;
  selectedTags.push(tagName);
  renderSelectedTags();
  const input = document.getElementById('tagsInput');
  const dropdown = document.getElementById('tagsDropdown');
  if (input) input.value = '';
  if (dropdown) dropdown.innerHTML = '';
  saveDraft();
  await saveTagIfNeeded(tagName);
};

window.removeTag = (name) => {
  selectedTags = selectedTags.filter(t => t !== name);
  renderSelectedTags();
  saveDraft();
};

const renderSelectedTags = () => {
  const container = document.getElementById('selectedTagsList');
  if (!container) return;
  container.innerHTML = selectedTags.map(t => `
    <span class="tag-selected">
      ${t}
      <button class="tag-remove" onclick="removeTag('${t}')"><i class="bi bi-x"></i></button>
    </span>
  `).join('');
};

// ── Title ──
const setupTitleInput = () => {
  const input = document.getElementById('postTitle');
  const counter = document.getElementById('titleCounter');
  const preview = document.getElementById('previewTitle');

  if (!input) return;

  input.addEventListener('input', () => {
    const len = input.value.length;
    const max = CONSTANTS.VALIDATION.TITLE_MAX;
    if (counter) {
      counter.textContent = `${len}/${max}`;
      counter.className = `char-counter ${len > max * 0.8 ? 'near-limit' : ''} ${len >= max ? 'at-limit' : ''}`;
    }
    if (preview) preview.textContent = input.value || 'Article Title Preview';
    saveDraft();
  });
};

// ── Content ──
const setupContentTextarea = () => {
  const textarea = document.getElementById('postContent');
  if (!textarea) return;

  textarea.addEventListener('input', () => {
    const readTime = Formatters.readingTime(textarea.value);
    const rtEl = document.getElementById('readTimeEstimate');
    if (rtEl) rtEl.textContent = readTime;
    updatePreviewContent(textarea.value);
    saveDraft();
  });
};

const updatePreviewContent = (content) => {
  const preview = document.getElementById('previewContent');
  if (!preview) return;
  preview.innerHTML = content
    .replace(/^# (.+)/gm, '<h1>$1</h1>')
    .replace(/^## (.+)/gm, '<h2>$1</h2>')
    .replace(/^### (.+)/gm, '<h3>$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/^/, '<p>')
    .replace(/$/, '</p>');
};

// ── Preview Toggle ──
const setupPreviewToggle = () => {
  const writeBtn = document.getElementById('writeMode');
  const previewBtn = document.getElementById('previewMode');
  const editorEl = document.getElementById('postEditor');
  const previewEl = document.getElementById('postPreview');

  writeBtn?.addEventListener('click', () => {
    isPreviewMode = false;
    writeBtn.classList.add('active');
    previewBtn?.classList.remove('active');
    editorEl?.classList.remove('d-none');
    previewEl?.classList.add('d-none');
  });

  previewBtn?.addEventListener('click', () => {
    isPreviewMode = true;
    previewBtn.classList.add('active');
    writeBtn?.classList.remove('active');
    editorEl?.classList.add('d-none');
    previewEl?.classList.remove('d-none');
    updatePreviewContent(document.getElementById('postContent')?.value || '');
  });
};

// ── Thumbnail ──
const setupThumbnail = () => {
  const input = document.getElementById('thumbnailUrl');
  const preview = document.getElementById('thumbnailPreview');
  const placeholder = document.getElementById('thumbnailPlaceholder');

  input?.addEventListener('input', Helpers.debounce(() => {
    const url = input.value.trim();
    if (!url) {
      preview?.classList.add('d-none');
      placeholder?.classList.remove('d-none');
      return;
    }
    if (preview) {
      preview.src = url;
      preview.onload = () => {
        preview.classList.remove('d-none');
        placeholder?.classList.add('d-none');
      };
      preview.onerror = () => {
        preview.classList.add('d-none');
        placeholder?.classList.remove('d-none');
      };
    }
    saveDraft();
  }, 500));
};

// ── Draft ──
const saveDraft = () => {
  clearTimeout(draftTimer);
  draftTimer = setTimeout(() => {
    Storage.setDraft({
      title: document.getElementById('postTitle')?.value || '',
      content: document.getElementById('postContent')?.value || '',
      excerpt: document.getElementById('postExcerpt')?.value || '',
      image: document.getElementById('thumbnailUrl')?.value || '',
      tags: selectedTags,
    });

    const indicator = document.getElementById('draftIndicator');
    if (indicator) {
      indicator.textContent = `Draft saved ${Formatters.timeAgo(new Date().toISOString())}`;
      indicator.classList.add('animate-fade-in');
    }
  }, 1500);
};

const loadDraft = () => {
  const draft = Storage.getDraft();
  if (!draft) return;

  const titleEl = document.getElementById('postTitle');
  const contentEl = document.getElementById('postContent');
  const excerptEl = document.getElementById('postExcerpt');
  const thumbnailEl = document.getElementById('thumbnailUrl');

  if (titleEl && draft.title) titleEl.value = draft.title;
  if (contentEl && draft.content) contentEl.value = draft.content;
  if (excerptEl && draft.excerpt) excerptEl.value = draft.excerpt;
  if (thumbnailEl && draft.image) thumbnailEl.value = draft.image;
  if (draft.tags?.length) {
    selectedTags = draft.tags;
    renderSelectedTags();
  }

  const indicator = document.getElementById('draftIndicator');
  if (indicator) indicator.textContent = `Draft restored from ${Formatters.timeAgo(new Date(draft.savedAt).toISOString())}`;
};

// ── Publish ──
const setupPublishForm = () => {
  const form = document.getElementById('createPostForm');
  if (!form) return;

  const setSubmitButtons = (disabled, label = 'Đăng bài') => {
    document.querySelectorAll('[type="submit"][form="createPostForm"], #createPostForm [type="submit"]').forEach(btn => {
      btn.disabled = disabled;
      if (disabled) {
        btn.dataset.originalHtml = btn.dataset.originalHtml || btn.innerHTML;
        btn.innerHTML = '<span class="spinner-custom" style="width:18px;height:18px;border-width:2px;"></span> Đang lưu...';
      } else if (btn.dataset.originalHtml) {
        btn.innerHTML = btn.dataset.originalHtml;
      } else {
        btn.innerHTML = `<i class="bi bi-send"></i> ${label}`;
      }
    });
  };

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    Validators.clearForm(form);
    const user = Storage.getUser();
    collectPendingTagInput();

    const data = {
      title: document.getElementById('postTitle')?.value?.trim(),
      content: document.getElementById('postContent')?.value?.trim(),
      excerpt: document.getElementById('postExcerpt')?.value?.trim(),
      image: document.getElementById('thumbnailUrl')?.value?.trim(),
      tags: [...selectedTags],
      status: document.getElementById('postStatus')?.value || 'published',
      author: user?.name || 'BlogHub Admin',
      authorId: user?.id || '',
      authorEmail: user?.email || '',
    };

    const errors = Validators.validatePostForm(data);
    if (Validators.hasErrors(errors)) {
      Validators.displayErrors(errors);
      Toast.warning('Lỗi nhập liệu', 'Vui lòng kiểm tra lại các trường được đánh dấu.');
      return;
    }

    setSubmitButtons(true);

    try {
      await syncSelectedTagsToApi();
      const post = await PostsAPI.create(data);
      Storage.clearDraft();
      Toast.success('Đã lưu lên MockAPI!', `Bài viết đã được ghi vào /posts với ID ${post.id}.`);
      setTimeout(() => window.location.href = `bai-viet.html?id=${post.id}`, 1200);
    } catch (err) {
      Toast.error('Không lưu được bài', err.message || 'Kiểm tra resource posts trên MockAPI.');
      setSubmitButtons(false);
    }
  });

  // Save as Draft button
  const draftBtn = document.getElementById('saveDraftBtn');
  draftBtn?.addEventListener('click', async () => {
    const title = document.getElementById('postTitle')?.value?.trim();
    if (!title) { Toast.warning('Thiếu tiêu đề', 'Vui lòng nhập tiêu đề trước.'); return; }

    draftBtn.disabled = true;
    try {
      const user = Storage.getUser();
      collectPendingTagInput();
      const data = {
        title,
        content: document.getElementById('postContent')?.value?.trim(),
        excerpt: document.getElementById('postExcerpt')?.value?.trim(),
        image: document.getElementById('thumbnailUrl')?.value?.trim(),
        tags: [...selectedTags],
        status: 'draft',
        author: user?.name || 'BlogHub Admin',
        authorId: user?.id || '',
        authorEmail: user?.email || '',
      };
      await syncSelectedTagsToApi();
      const post = await PostsAPI.create(data);
      Storage.clearDraft();
      Toast.success('Đã lưu nháp lên MockAPI!', `Bản nháp đã được ghi vào /posts với ID ${post.id}.`);
    } catch (err) {
      Toast.error('Lỗi', err.message);
    } finally {
      draftBtn.disabled = false;
    }
  });
};

document.addEventListener('DOMContentLoaded', initCreatePost);
