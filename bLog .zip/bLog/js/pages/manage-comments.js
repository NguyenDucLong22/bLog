/**
 * BlogHub - Manage Comments Page Script
 */

let allComments = [];
let filteredComments = [];
let currentPage = 1;
const PER_PAGE = CONSTANTS.TABLE_PER_PAGE;

const initManageComments = async () => {
  if (!Sidebar.requireAuth()) return;
  await loadComments();
  setupFilters();
};

const loadComments = async () => {
  const tbody = document.getElementById('commentsTbody');
  if (!tbody) return;

  Loader.showSkeleton(tbody, 5, 'row');

  try {
    const data = await CommentsAPI.getAll({ limit: 200 });
    allComments = Array.isArray(data) ? data : [];
    filteredComments = [...allComments];
    renderTable();
    updateCounts();
  } catch (err) {
    let errMsg = err.message;
    if (errMsg.includes('404') || errMsg.toLowerCase().includes('not found')) {
      errMsg = 'Lỗi 404: Bạn chưa tạo bảng dữ liệu "comments" trên MockAPI. Vui lòng vào MockAPI tạo New resource tên là "comments" nhé!';
    }
    Loader.showError(tbody, errMsg, loadComments);
  }
};

const renderTable = () => {
  const tbody = document.getElementById('commentsTbody');
  if (!tbody) return;

  const total = Pagination.totalPages(filteredComments.length, PER_PAGE);
  const page = Pagination.paginate(filteredComments, currentPage, PER_PAGE);

  if (!page.length) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center py-5" style="color:var(--text-tertiary);">Không tìm thấy bình luận nào</td></tr>`;
    document.getElementById('commentsPagination').innerHTML = '';
    return;
  }

  tbody.innerHTML = page.map(c => `
    <tr class="comment-row-${c.status}" data-id="${c.id}">
      <td>
        <div class="d-flex align-items-center gap-2">
          <img src="${Helpers.getAvatarUrl(c.name || 'User')}" alt="${c.name}" class="avatar avatar-sm">
          <div>
            <div style="font-weight:600;font-size:0.8125rem;">${c.name || 'Anonymous'}</div>
            <div style="font-size:0.75rem;color:var(--text-tertiary);">${c.email || ''}</div>
          </div>
        </div>
      </td>
      <td>
        <div class="comment-content-cell">${c.content || c.text || ''}</div>
      </td>
      <td>
        <a href="bai-viet.html?id=${c.postId}" style="font-size:0.8125rem;color:var(--color-primary);" target="_blank">
          Bài viết #${c.postId}
        </a>
      </td>
      <td>${Formatters.commentStatusBadge(c.status)}</td>
      <td style="font-size:0.8125rem;color:var(--text-secondary);">${Formatters.timeAgo(c.createdAt)}</td>
      <td>
        <div class="action-btn-group">
          ${c.status !== 'approved' ? `<button class="action-btn approve" title="Duyệt" onclick="moderateComment('${c.id}', 'approved')"><i class="bi bi-check"></i></button>` : ''}
          ${c.status !== 'rejected' ? `<button class="action-btn reject" title="Từ chối" onclick="moderateComment('${c.id}', 'rejected')"><i class="bi bi-x"></i></button>` : ''}
          <button class="action-btn delete" title="Xoá" onclick="deleteCommentRow('${c.id}')"><i class="bi bi-trash"></i></button>
        </div>
      </td>
    </tr>
  `).join('');

  const paginationEl = document.getElementById('commentsPagination');
  if (paginationEl) {
    Pagination.render(paginationEl, currentPage, total, (pg) => {
      currentPage = pg;
      renderTable();
    });
  }
};

const updateCounts = () => {
  const pending = allComments.filter(c => c.status === 'pending').length;
  const approved = allComments.filter(c => c.status === 'approved').length;
  const el = document.getElementById('pendingCount');
  if (el) el.textContent = pending;
  const approvedEl = document.getElementById('approvedCount');
  if (approvedEl) approvedEl.textContent = approved;
  const totalEl = document.getElementById('totalComments');
  if (totalEl) totalEl.textContent = allComments.length;
};

const setupFilters = () => {
  document.querySelectorAll('[data-comment-status]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-comment-status]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const status = btn.dataset.commentStatus;
      filteredComments = status === 'all' ? [...allComments] : allComments.filter(c => c.status === status);
      currentPage = 1;
      renderTable();
    });
  });

  const searchInput = document.getElementById('commentSearch');
  searchInput?.addEventListener('input', Helpers.debounce((e) => {
    const q = e.target.value.toLowerCase();
    filteredComments = q ? allComments.filter(c =>
      (c.name || '').toLowerCase().includes(q) ||
      (c.content || '').toLowerCase().includes(q)
    ) : [...allComments];
    currentPage = 1;
    renderTable();
  }, 300));
};

// Global moderateComment
window.moderateComment = async (id, status) => {
  try {
    await CommentsAPI.update(id, { status });
    const idx = allComments.findIndex(c => c.id == id);
    if (idx > -1) allComments[idx].status = status;
    filteredComments = [...allComments];
    renderTable();
    updateCounts();
    Toast.success('Đã cập nhật!', `Bình luận đã được ${status === 'approved' ? 'duyệt' : 'từ chối'}.`);
  } catch (err) {
    Toast.error('Lỗi', err.message);
  }
};

window.deleteCommentRow = (id) => {
  Modal.confirm({
    title: 'Xoá bình luận',
    message: 'Bạn có chắc chắn muốn xoá vĩnh viễn bình luận này không?',
    confirmText: 'Xoá',
    type: 'danger',
    onConfirm: async () => {
      try {
        await CommentsAPI.remove(id);
        allComments = allComments.filter(c => c.id != id);
        filteredComments = filteredComments.filter(c => c.id != id);
        const row = document.querySelector(`tr[data-id="${id}"]`);
        if (row) $(row).animate({ opacity: 0 }, 200, () => { row.remove(); });
        updateCounts();
        Toast.success('Đã xoá!', 'Bình luận đã được xoá.');
      } catch (err) {
        Toast.error('Lỗi', err.message);
      }
    },
  });
};

document.addEventListener('DOMContentLoaded', initManageComments);
