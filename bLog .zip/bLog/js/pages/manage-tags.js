/**
 * BlogHub - Manage Tags Page Script
 */

let allTags = [];
let editingTagId = null;

const initManageTags = async () => {
  if (!Sidebar.requireAuth()) return;
  await loadTags();
  setupAddTagForm();
  setupEditTagForm();
  renderColorPicker('addColorPicker', 'addTagColor');
};

const loadTags = async () => {
  const container = document.getElementById('tagsGrid');
  if (!container) return;

  Loader.showSkeleton(container, 8, 'card');

  try {
    const tags = await TagsAPI.getAll();
    allTags = Array.isArray(tags) ? tags : [];

    if (!allTags.length) {
      Loader.showEmpty(container, 'No tags yet', 'Add your first tag to organize posts.');
      return;
    }

    container.innerHTML = allTags.map(t => Cards.tagCard(t)).join('');
  } catch (err) {
    Loader.showError(container, err.message, loadTags);
  }
};

// ── Color Picker ──
const renderColorPicker = (containerId, inputId) => {
  const container = document.getElementById(containerId);
  if (!container) return;

  container.innerHTML = CONSTANTS.TAG_COLORS.map(color => `
    <div class="color-swatch ${color.name === 'purple' ? 'selected' : ''}"
         style="background:${color.value};"
         data-color="${color.name}"
         title="${color.label}"
         onclick="selectColor('${containerId}', '${inputId}', '${color.name}', this)">
    </div>
  `).join('');

  const input = document.getElementById(inputId);
  if (input) input.value = 'purple';
};

window.selectColor = (containerId, inputId, colorName, el) => {
  document.querySelectorAll(`#${containerId} .color-swatch`).forEach(s => s.classList.remove('selected'));
  el.classList.add('selected');
  const input = document.getElementById(inputId);
  if (input) input.value = colorName;
};

// ── Add Tag ──
const setupAddTagForm = () => {
  const form = document.getElementById('addTagForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    Validators.clearForm(form);

    const data = {
      name: document.getElementById('addTagName')?.value?.trim(),
      color: document.getElementById('addTagColor')?.value || 'purple',
      description: document.getElementById('addTagDesc')?.value?.trim() || '',
    };

    const errors = Validators.validateTagForm(data);
    if (Validators.hasErrors(errors)) { Validators.displayErrors(errors); return; }

    // Check duplicate
    if (allTags.some(t => t.name.toLowerCase() === data.name.toLowerCase())) {
      Validators.displayErrors({ name: 'This tag already exists.' });
      return;
    }

    const btn = form.querySelector('[type="submit"]');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-custom" style="width:16px;height:16px;border-width:2px;"></span>';

    try {
      const newTag = await TagsAPI.create(data);
      allTags.unshift(newTag);
      Modal.hide('addTagModal');
      form.reset();
      renderColorPicker('addColorPicker', 'addTagColor');

      const container = document.getElementById('tagsGrid');
      if (container) {
        container.insertAdjacentHTML('afterbegin', Cards.tagCard(newTag));
        $(container.firstElementChild).hide().slideDown(300);
      }

      Toast.success('Tag created!', `#${data.name} has been added.`);
    } catch (err) {
      Toast.error('Error', err.message);
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-plus"></i> Create Tag';
    }
  });
};

// ── Edit Tag ──
window.openEditTagModal = async (id) => {
  editingTagId = id;
  const tag = allTags.find(t => t.id == id);
  if (!tag) return;

  document.getElementById('editTagName').value = tag.name || '';
  document.getElementById('editTagDesc').value = tag.description || '';
  renderColorPicker('editColorPicker', 'editTagColor');

  // Pre-select current color
  setTimeout(() => {
    const swatch = document.querySelector(`#editColorPicker [data-color="${tag.color}"]`);
    if (swatch) {
      document.querySelectorAll('#editColorPicker .color-swatch').forEach(s => s.classList.remove('selected'));
      swatch.classList.add('selected');
      document.getElementById('editTagColor').value = tag.color;
    }
  }, 50);

  Modal.show('editTagModal');
};

const setupEditTagForm = () => {
  const form = document.getElementById('editTagForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!editingTagId) return;
    Validators.clearForm(form);

    const data = {
      name: document.getElementById('editTagName')?.value?.trim(),
      color: document.getElementById('editTagColor')?.value || 'purple',
      description: document.getElementById('editTagDesc')?.value?.trim() || '',
    };

    const errors = Validators.validateTagForm(data);
    if (Validators.hasErrors(errors)) { Validators.displayErrors(errors); return; }

    const btn = form.querySelector('[type="submit"]');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-custom" style="width:16px;height:16px;border-width:2px;"></span>';

    try {
      await TagsAPI.update(editingTagId, data);
      const idx = allTags.findIndex(t => t.id == editingTagId);
      if (idx > -1) allTags[idx] = { ...allTags[idx], ...data };
      Modal.hide('editTagModal');
      await loadTags();
      Toast.success('Updated!', `Tag updated successfully.`);
    } catch (err) {
      Toast.error('Error', err.message);
    } finally {
      btn.disabled = false;
      btn.innerHTML = 'Save Changes';
    }
  });
};

// ── Delete Tag ──
window.confirmDeleteTag = (id, name) => {
  Modal.confirm({
    title: 'Delete Tag',
    message: `Delete tag "<strong>#${name}</strong>"? Posts using this tag won't be deleted.`,
    confirmText: 'Delete',
    type: 'danger',
    onConfirm: async () => {
      try {
        await TagsAPI.remove(id);
        allTags = allTags.filter(t => t.id != id);
        const card = document.querySelector(`.tag-card[data-id="${id}"]`);
        if (card) $(card).animate({ opacity: 0, height: 0 }, 300, () => card.remove());
        Toast.success('Deleted!', `Tag #${name} deleted.`);
      } catch (err) {
        Toast.error('Error', err.message);
      }
    },
  });
};

document.addEventListener('DOMContentLoaded', initManageTags);
