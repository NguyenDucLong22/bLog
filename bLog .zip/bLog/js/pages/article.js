/**
 * BlogHub - Article Detail Page
 */

let currentPost = null;
let comments = [];
let commentsPage = 1;
let activePostId = null;

const initArticle = async () => {
  const postId = Helpers.getQueryParam('id');
  if (!postId) {
    window.location.href = 'index.html';
    return;
  }
  activePostId = postId;

  setupReadingProgress();
  await Promise.all([loadPost(postId), loadComments(postId)]);
};

// ── Reading Progress Bar ──
const setupReadingProgress = () => {
  const bar = document.getElementById('readingProgress');
  if (!bar) return;

  const update = Helpers.throttle(() => {
    const article = document.getElementById('articleContent');
    if (!article) return;

    const articleTop = article.getBoundingClientRect().top + window.scrollY;
    const articleBottom = articleTop + article.offsetHeight;
    const scrolled = window.scrollY + window.innerHeight;
    const progress = Math.min(1, Math.max(0, (scrolled - articleTop) / (articleBottom - articleTop)));

    bar.style.transform = `scaleX(${progress})`;
  }, 50);

  window.addEventListener('scroll', update, { passive: true });
};

// ── Load Post ──
const loadPost = async (id) => {
  const hero = document.getElementById('articleHero');
  const body = document.getElementById('articleBody');

  if (hero) Loader.showSkeleton(hero, 1, 'card');

  try {
    const post = await PostsAPI.getById(id);
    currentPost = post;

    renderArticleHero(post);
    renderArticleBody(post);
    renderAuthorCard(post);
    renderArticleTagsCloud(post.tags || []);
    syncPostTagsToApi(post.tags || []);

    // Increment views
    PostsAPI.incrementViews(id, post.views || 0).catch(() => {});

    // Page title
    document.title = `${post.title} – BlogHub`;

    // Load related posts
    loadRelatedPosts(post.tags || [], id);

  } catch (err) {
    if (body) Loader.showError(body, err.message, () => loadPost(id));
  }
};

const renderArticleHero = (post) => {
  const hero = document.getElementById('articleHero');
  if (!hero) return;

  const image = post.image || `https://picsum.photos/seed/${post.id}/1400/600`;
  const tags = Array.isArray(post.tags) ? post.tags : [];
  const avatar = post.authorAvatar || Helpers.getAvatarUrl(post.author || 'A');

  hero.innerHTML = `
    <img src="${image}" alt="${post.title}" class="article-hero-img" loading="eager"
         onerror="this.src='https://picsum.photos/seed/article/1400/600'">
    <div class="article-hero-overlay"></div>
    <div class="article-hero-content">
      <div class="container-custom">
        <div class="article-category mb-3">
          ${tags.slice(0, 3).map(t => `<span class="badge-custom badge-primary me-1">${t}</span>`).join('')}
        </div>
        <h1 class="article-title animate-fade-in-up">${post.title}</h1>
        <div class="article-meta">
          <div class="article-author-info">
            <img src="${avatar}" alt="${post.author}" class="avatar avatar-md"
                 onerror="this.src='${Helpers.getAvatarUrl('A')}'">
            <div>
              <div class="article-author-name">${post.author || 'Anonymous'}</div>
              <div class="article-author-title">Author</div>
            </div>
          </div>
          <div class="article-meta-divider"></div>
          <div class="article-meta-item">
            <i class="bi bi-calendar3"></i>
            <span>${Formatters.formatDate(post.createdAt)}</span>
          </div>
          <div class="article-meta-item">
            <i class="bi bi-clock"></i>
            <span>${Formatters.readingTime(post.content || '')}</span>
          </div>
          <div class="article-meta-item">
            <i class="bi bi-eye"></i>
            <span>${Formatters.formatNumber((post.views || 0) + 1)} views</span>
          </div>
        </div>
      </div>
    </div>
  `;
};

const normalizeTagName = (name) => `${name || ''}`.trim().replace(/\s+/g, ' ');

const syncPostTagsToApi = async (tags = []) => {
  const names = [...new Set(tags.map(normalizeTagName).filter(Boolean))];
  if (!names.length || typeof TagsAPI === 'undefined') return;

  try {
    const existingTags = await TagsAPI.getAll();
    const existingNames = Array.isArray(existingTags)
      ? existingTags.map(t => String(t.name || '').toLowerCase())
      : [];

    await Promise.all(names
      .filter(name => !existingNames.includes(name.toLowerCase()))
      .map(name => TagsAPI.create({
        name,
        color: 'purple',
        description: '',
      }))
    );
  } catch (err) {
    console.warn('Could not sync article tags to MockAPI:', err.message);
  }
};

const renderArticleTagsCloud = (tags = []) => {
  const container = document.getElementById('articleTagsCloud');
  if (!container) return;

  const names = [...new Set(tags.map(normalizeTagName).filter(Boolean))];
  if (!names.length) {
    container.innerHTML = '<span style="color:var(--text-tertiary);font-size:0.8125rem;">Chưa có chủ đề</span>';
    return;
  }

  container.innerHTML = names.map(tag => `
    <a href="index.html?tag=${encodeURIComponent(tag)}#postsSection" class="tag-pill" data-tag="${tag}">${tag}</a>
  `).join('');
};

const renderAuthorCard = (post) => {
  const container = document.getElementById('authorCard');
  if (!container) return;

  const authorName = post.author || 'Người đăng';
  const authorEmail = post.authorEmail || '';
  const avatar = post.authorAvatar || Helpers.getAvatarUrl(authorName);

  container.innerHTML = `
    <div class="d-flex align-items-center gap-3">
      <img src="${avatar}" alt="${authorName}" class="avatar avatar-lg"
           onerror="this.src='${Helpers.getAvatarUrl(authorName)}'">
      <div style="min-width:0;">
        <div style="font-weight:700;color:var(--text-primary);overflow-wrap:anywhere;">${authorName}</div>
        <div style="font-size:0.8125rem;color:var(--text-tertiary);overflow-wrap:anywhere;">${authorEmail || 'Tác giả BlogHub'}</div>
      </div>
    </div>
  `;
};

const renderArticleBody = (post) => {
  const body = document.getElementById('articleBody');
  if (!body) return;

  const tags = Array.isArray(post.tags) ? post.tags : [];
  const isLiked = Storage.isPostLiked(post.id);

  const content = post.content || `
    <p>${post.excerpt || 'This article has no content yet.'}</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
    <h2>Getting Started</h2>
    <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.</p>
    <blockquote>The best way to predict the future is to create it.</blockquote>
    <h3>Key Takeaways</h3>
    <ul>
      <li>Build with modern standards in mind</li>
      <li>Focus on user experience above all</li>
      <li>Keep learning and iterating</li>
    </ul>
  `;

  body.innerHTML = `
    <div class="article-content" id="articleContent">
      ${content}
    </div>

    <div class="article-tags">${Formatters.formatTags(tags, true)}</div>

    <div class="share-bar">
      <span class="share-label">Share:</span>
      <a href="https://twitter.com/intent/tweet?text=${encodeURIComponent(post.title)}&url=${encodeURIComponent(window.location.href)}" 
         target="_blank" class="share-btn twitter" title="Share on Twitter">
        <i class="bi bi-twitter-x"></i>
      </a>
      <a href="https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}" 
         target="_blank" class="share-btn facebook" title="Share on Facebook">
        <i class="bi bi-facebook"></i>
      </a>
      <a href="https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(window.location.href)}&title=${encodeURIComponent(post.title)}"
         target="_blank" class="share-btn linkedin" title="Share on LinkedIn">
        <i class="bi bi-linkedin"></i>
      </a>
      <button class="share-btn copy" title="Copy link" id="copyLinkBtn">
        <i class="bi bi-link-45deg"></i>
      </button>
    </div>

    <div class="reaction-bar">
      <button class="reaction-btn ${isLiked ? 'active' : ''}" id="likeBtn">
        <i class="bi bi-heart${isLiked ? '-fill' : ''}"></i>
        <span id="likeCount">${Formatters.formatNumber(post.likes || 0)}</span> Likes
      </button>
      <button class="reaction-btn" id="bookmarkBtn">
        <i class="bi bi-bookmark"></i> Save
      </button>
    </div>
  `;

  // Copy link
  document.getElementById('copyLinkBtn')?.addEventListener('click', async () => {
    await Helpers.copyToClipboard(window.location.href);
    Toast.success('Link copied!', 'URL copied to clipboard.');
  });

  // Like button
  document.getElementById('likeBtn')?.addEventListener('click', async () => {
    if (Storage.isPostLiked(post.id)) {
      Toast.info('Already liked', 'You\'ve already liked this post!');
      return;
    }
    try {
      const updated = await PostsAPI.like(post.id, post.likes || 0);
      Storage.addLikedPost(post.id);
      const btn = document.getElementById('likeBtn');
      const count = document.getElementById('likeCount');
      if (btn) { btn.classList.add('active'); btn.querySelector('i').className = 'bi bi-heart-fill'; }
      if (count) count.textContent = Formatters.formatNumber((post.likes || 0) + 1);
      Toast.success('Liked!', 'Thanks for the love!');
    } catch (err) {
      Toast.error('Error', 'Could not like post. Try again.');
    }
  });
};

// ── Related Posts ──
const loadRelatedPosts = async (tags, excludeId) => {
  const container = document.getElementById('relatedPosts');
  if (!container) return;

  try {
    const related = await PostsAPI.getRelated(tags, excludeId, 3);

    if (!related.length) {
      container.innerHTML = '<p style="color:var(--text-tertiary);font-size:0.875rem;">No related posts found.</p>';
      return;
    }

    container.innerHTML = related.map(p => `
      <a href="bai-viet.html?id=${p.id}" class="related-post-card">
        <img src="${p.image || 'https://picsum.photos/seed/' + p.id + '/200/150'}" 
             alt="${p.title}" class="related-post-img"
             onerror="this.src='https://picsum.photos/seed/${p.id + 200}/200/150'">
        <div>
          <div class="related-post-title">${p.title}</div>
          <div class="related-post-meta">${Formatters.readingTime(p.content || '')} · ${Formatters.timeAgo(p.createdAt)}</div>
        </div>
      </a>
    `).join('');
  } catch (err) {
    container.innerHTML = '';
  }
};

// ── Comments ──
const loadComments = async (postId) => {
  const container = document.getElementById('commentsContainer');
  const countEl = document.getElementById('commentsCount');
  if (!container) return;

  Loader.showSkeleton(container, 3, 'comment');

  try {
    const data = await CommentsAPI.getByPostId(postId, 1, 100);

    comments = Array.isArray(data) ? data.filter(c => c.status !== 'rejected') : [];
    renderCommentsList(comments, container, countEl);

  } catch (err) {
    Loader.showError(container, err.message || 'Không tải được bình luận.', () => loadComments(postId));
    if (countEl) countEl.textContent = '0';
  }

  setupCommentForm(postId);
};

const renderCommentsList = (list, container, countEl) => {
  if (countEl) countEl.textContent = list.length;

  if (!list.length) {
    Loader.showEmpty(container, 'Chưa có bình luận', 'Hãy là người đầu tiên chia sẻ suy nghĩ của bạn!');
    return;
  }

  const parents = list
    .filter(c => !c.parentId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const repliesByParent = list
    .filter(c => c.parentId)
    .reduce((map, reply) => {
      const key = String(reply.parentId);
      if (!map[key]) map[key] = [];
      map[key].push(reply);
      return map;
    }, {});

  Object.values(repliesByParent).forEach(replies => {
    replies.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  });

  container.innerHTML = parents
    .map(c => Cards.commentCard(c, false, repliesByParent[String(c.id)] || []))
    .join('');

  $(container).children().each(function (i) {
    $(this).hide().delay(i * 80).slideDown(300);
  });
};

const setupCommentForm = (postId) => {
  const form = document.getElementById('commentForm');
  if (!form) return;
  if (form.dataset.ready === 'true') return;
  form.dataset.ready = 'true';

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    Validators.clearForm(form);

    const data = {
      name: document.getElementById('commentName')?.value?.trim(),
      email: document.getElementById('commentEmail')?.value?.trim(),
      content: document.getElementById('commentText')?.value?.trim(),
      postId,
      parentId: '',
    };

    const errors = Validators.validateCommentForm(data);
    if (Validators.hasErrors(errors)) {
      Validators.displayErrors(errors);
      return;
    }

    const submitBtn = form.querySelector('[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-custom" style="width:18px;height:18px;border-width:2px;"></span> Posting...';

    try {
      await CommentsAPI.create(data);
      Toast.success('Đã lưu bình luận!', 'Bình luận đã được ghi vào MockAPI.');
      form.reset();
      await loadComments(postId);

    } catch (err) {
      Toast.error('Không lưu được bình luận', err.message || 'Kiểm tra resource comments trên MockAPI.');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<i class="bi bi-send"></i> Đăng bình luận';
    }
  });
};

window.showReplyForm = (commentId, commentName = 'bình luận này') => {
  document.querySelectorAll('.reply-form-slot').forEach(slot => {
    if (slot.id !== `replyForm-${commentId}`) slot.innerHTML = '';
  });

  const slot = document.getElementById(`replyForm-${commentId}`);
  if (!slot) return;

  slot.innerHTML = `
    <form class="reply-form" onsubmit="submitReply(event, '${commentId}')">
      <div class="reply-form-title">Trả lời ${commentName}</div>
      <div class="comment-input-grid mb-2">
        <input type="text" class="form-control-custom" name="name" placeholder="Tên của bạn" required>
        <input type="email" class="form-control-custom" name="email" placeholder="email@của-bạn.com" required>
      </div>
      <textarea class="comment-textarea" name="content" placeholder="Viết phản hồi..." rows="3" required></textarea>
      <div class="reply-form-actions">
        <button type="submit" class="btn-primary-custom"><i class="bi bi-send"></i> Gửi trả lời</button>
        <button type="button" class="btn-ghost-custom" onclick="cancelReply('${commentId}')">Huỷ</button>
      </div>
    </form>
  `;
};

window.cancelReply = (commentId) => {
  const slot = document.getElementById(`replyForm-${commentId}`);
  if (slot) slot.innerHTML = '';
};

window.submitReply = async (event, parentId) => {
  event.preventDefault();
  const form = event.target;
  const data = {
    name: form.elements.name.value.trim(),
    email: form.elements.email.value.trim(),
    content: form.elements.content.value.trim(),
    postId: activePostId,
    parentId,
  };

  const errors = Validators.validateCommentForm(data);
  if (Validators.hasErrors(errors)) {
    Toast.warning('Thiếu thông tin', 'Vui lòng nhập tên, email và nội dung trả lời hợp lệ.');
    return;
  }

  const submitBtn = form.querySelector('[type="submit"]');
  submitBtn.disabled = true;
  submitBtn.innerHTML = '<span class="spinner-custom" style="width:16px;height:16px;border-width:2px;"></span> Đang gửi...';

  try {
    await CommentsAPI.create(data);
    Toast.success('Đã lưu trả lời!', 'Phản hồi đã được ghi vào MockAPI.');
    await loadComments(activePostId);
  } catch (err) {
    Toast.error('Không lưu được trả lời', err.message || 'Kiểm tra resource comments trên MockAPI.');
    submitBtn.disabled = false;
    submitBtn.innerHTML = '<i class="bi bi-send"></i> Gửi trả lời';
  }
};

document.addEventListener('DOMContentLoaded', initArticle);
