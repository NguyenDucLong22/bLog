/**
 * BlogHub - Home Page Script
 * Handles hero, trending posts, latest posts, search, category filter, newsletter
 */

// ── State ──
let allPosts = [];
let currentPage = 1;
let activeCategory = 'all';
let activeTag = '';
const POSTS_PER_PAGE = CONSTANTS.POSTS_PER_PAGE;

// ── DOM Elements ──
const postsGrid = document.getElementById('postsGrid');
const trendingContainer = document.getElementById('trendingPosts');
const paginationContainer = document.getElementById('pagination');
const categoryTabsEl = document.getElementById('categoryTabs');
const heroSearchInput = document.getElementById('heroSearch');
const heroSearchBtn = document.getElementById('heroSearchBtn');
const searchSuggestions = document.getElementById('searchSuggestions');
const newsletterForm = document.getElementById('newsletterForm');

const normalizeTagName = (name) => `${name || ''}`.trim().replace(/\s+/g, ' ');

// ── Bootstrap ──
const initHome = async () => {
  await Promise.all([
    loadFeaturedPost(),
    loadTrendingPosts(),
    loadPosts(),
    loadTagsCloud(),
  ]);

  setupSearch();
  setupCategoryFilter();
  setupNewsletter();
  setupTagFilter();
};

// ── Loaders ──
const loadFeaturedPost = async () => {
  const container = document.getElementById('featuredPost');
  if (!container) return;

  try {
    const posts = await PostsAPI.getLatest(3);
    if (!posts || posts.length === 0) return;

    const carouselItems = posts.map((post, index) => {
      const image = post.image || `https://picsum.photos/seed/${post.id}/1200/600`;
      const tags = Array.isArray(post.tags) ? post.tags : [];
      return `
        <div class="carousel-item ${index === 0 ? 'active' : ''}">
          <div class="featured-post" style="margin:0; box-shadow:none; height:100%;">
            <img src="${image}" alt="${post.title}" class="featured-post-img" loading="lazy" onerror="this.src='https://picsum.photos/seed/featured/1200/600'">
            <div class="featured-post-overlay"></div>
            <div class="featured-post-content">
              <div class="mb-3">
                ${tags.slice(0, 2).map(t => `<span class="badge-custom badge-primary me-1">${t}</span>`).join('')}
              </div>
              <h2 class="featured-post-title">${post.title}</h2>
              <p class="featured-post-excerpt">${Helpers.truncate(Helpers.stripHtml(post.excerpt || post.content || ''), 120)}</p>
              <div class="d-flex align-items-center gap-3">
                <a href="bai-viet.html?id=${post.id}" class="btn-primary-custom" style="padding:0.5rem 1rem;font-size:0.875rem;">
                  Đọc tiếp <i class="bi bi-arrow-right"></i>
                </a>
                <span style="color:rgba(255,255,255,0.7);font-size:0.8125rem;">
                  <i class="bi bi-clock"></i> ${Formatters.readingTime(post.content || '')}
                </span>
              </div>
            </div>
          </div>
        </div>
      `;
    }).join('');

    container.innerHTML = `
      <div id="heroCarousel" class="carousel slide carousel-fade shadow-lg" data-bs-ride="carousel" data-bs-interval="3500" style="border-radius:var(--radius-2xl);overflow:hidden;height:100%;min-height:360px;">
        <div class="carousel-indicators" style="margin-bottom:0.5rem;">
          ${posts.map((_, i) => `<button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="${i}" class="${i === 0 ? 'active' : ''}" aria-label="Slide ${i + 1}"></button>`).join('')}
        </div>
        <div class="carousel-inner" style="height:100%;">
          ${carouselItems}
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev" style="width:10%;">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next" style="width:10%;">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    `;

    container.querySelectorAll('.featured-post-img').forEach((img, idx) => {
      img.addEventListener('error', (e) => {
        e.target.src = `https://picsum.photos/seed/bloghub${idx}/1200/600`;
      });
    });
  } catch (err) {
    container.innerHTML = '';
    console.warn('Featured post failed:', err.message);
  }
};

const loadTrendingPosts = async () => {
  if (!trendingContainer) return;
  Loader.showSkeleton(trendingContainer, 5, 'trending');

  try {
    const trending = await PostsAPI.getTrending(5);
    if (!trending.length) {
      trendingContainer.innerHTML = '<p style="color:var(--text-tertiary);font-size:0.875rem;text-align:center;padding:1rem;">Chưa có bài viết nổi bật.</p>';
      return;
    }

    trendingContainer.innerHTML = trending.map((p, i) => Cards.trendingCard(p, i)).join('');

    // jQuery fadeIn for trending
    $(trendingContainer).children().each(function (i) {
      $(this).hide().delay(i * 100).fadeIn(400);
    });

  } catch (err) {
    trendingContainer.innerHTML = '<p style="color:var(--color-accent-red);font-size:0.875rem;padding:1rem;">Không tải được bài viết nổi bật.</p>';
  }
};

const loadPosts = async (tag = '', page = 1) => {
  if (!postsGrid) return;
  Loader.showSkeleton(postsGrid, POSTS_PER_PAGE, 'card');

  try {
    let posts;
    if (tag) {
      posts = await PostsAPI.getByTag(tag, 100);
    } else {
      posts = await PostsAPI.getLatest(100);
    }

    allPosts = Array.isArray(posts) ? posts : [];
    renderCategoryTabs(allPosts);

    // Apply category filter
    let filtered = filterByCategory(allPosts, activeCategory);

    // Apply tag filter from URL
    const tagParam = Helpers.getQueryParam('tag');
    if (tagParam && !tag) {
      activeTag = tagParam;
      filtered = filtered.filter(p =>
        Array.isArray(p.tags) && p.tags.some(t => t.toLowerCase() === tagParam.toLowerCase())
      );
    }

    renderPosts(filtered, page);

  } catch (err) {
    Loader.showError(postsGrid, err.message, () => loadPosts(tag, page));
  }
};

const renderPosts = (posts, page = 1) => {
  currentPage = page;
  const total = Pagination.totalPages(posts.length, POSTS_PER_PAGE);
  const paginated = Pagination.paginate(posts, page, POSTS_PER_PAGE);

  if (!paginated.length) {
    Loader.showEmpty(postsGrid, 'Không tìm thấy bài viết', 'Thử chọn danh mục khác hoặc từ khóa khác.');
    if (paginationContainer) paginationContainer.innerHTML = '';
    return;
  }

  postsGrid.innerHTML = paginated.map(p => Cards.postCard(p)).join('');

  // Reveal animations
  Navbar.setupRevealAnimations?.();
  setTimeout(() => {
    document.querySelectorAll('.reveal').forEach(el => el.classList.add('revealed'));
  }, 100);

  // Pagination
  if (paginationContainer) {
    Pagination.render(paginationContainer, page, total, (newPage) => {
      renderPosts(posts, newPage);
      Helpers.scrollTo('#postsSection', 100);
    });
  }
};

// ── Category filter ──
const getTagsFromPosts = (posts) => {
  const counts = new Map();
  posts.forEach(post => {
    if (!Array.isArray(post.tags)) return;
    post.tags.map(normalizeTagName).filter(Boolean).forEach(tag => {
      counts.set(tag, (counts.get(tag) || 0) + 1);
    });
  });

  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'vi'))
    .map(([name]) => name);
};

const renderCategoryTabs = (posts) => {
  if (!categoryTabsEl) return;
  const tags = getTagsFromPosts(posts);

  categoryTabsEl.innerHTML = `
    <button class="category-tab ${activeCategory === 'all' ? 'active' : ''}" data-category="all">Tất cả</button>
    ${tags.map(tag => `
      <button class="category-tab ${activeCategory.toLowerCase() === tag.toLowerCase() ? 'active' : ''}" data-category="${tag}">${tag}</button>
    `).join('')}
  `;
};

const filterByCategory = (posts, category) => {
  if (!category || category === 'all') return posts;
  return posts.filter(p =>
    Array.isArray(p.tags) && p.tags.some(t => normalizeTagName(t).toLowerCase() === category.toLowerCase())
  );
};

const setupCategoryFilter = () => {
  if (!categoryTabsEl) return;

  categoryTabsEl.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-category]');
    if (!btn) return;

    categoryTabsEl.querySelectorAll('[data-category]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    activeCategory = btn.dataset.category;
    activeTag = '';
    renderPosts(filterByCategory(allPosts, activeCategory));
  });
};

// ── Tag filter from sidebar ──
const setupTagFilter = () => {
  document.querySelectorAll('[data-tag]').forEach(el => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      const tag = el.dataset.tag;
      activeTag = tag;
      activeCategory = 'all';
      document.querySelectorAll('[data-category]').forEach(b => b.classList.remove('active'));
      document.querySelector('[data-category="all"]')?.classList.add('active');
      loadPosts(tag);
      Helpers.scrollTo('#postsSection');
    });
  });
};

// ── Search ──
const setupSearch = () => {
  if (!heroSearchInput) return;

  const debouncedSearch = Helpers.debounce(async (query) => {
    if (query.length < 2) {
      if (searchSuggestions) searchSuggestions.innerHTML = '';
      return;
    }

    try {
      const results = await PostsAPI.search(query, 6);
      renderSearchSuggestions(results, query);
      Helpers.addRecentSearch(query);
    } catch (err) {
      if (searchSuggestions) searchSuggestions.innerHTML = '';
    }
  }, CONSTANTS.SEARCH_DEBOUNCE_MS);

  heroSearchInput.addEventListener('input', (e) => debouncedSearch(e.target.value));

  // Click outside to close
  document.addEventListener('click', (e) => {
    if (!heroSearchInput.contains(e.target)) {
      if (searchSuggestions) searchSuggestions.innerHTML = '';
    }
  });

  // Search button
  heroSearchBtn?.addEventListener('click', () => {
    const query = heroSearchInput.value.trim();
    if (query) performSearch(query);
  });

  heroSearchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const query = heroSearchInput.value.trim();
      if (query) performSearch(query);
    }
  });
};

const renderSearchSuggestions = (results, query) => {
  if (!searchSuggestions) return;

  if (!results.length) {
    searchSuggestions.innerHTML = `
      <div class="search-suggestion-item" style="cursor:default;">
        <div class="search-suggestion-icon"><i class="bi bi-search"></i></div>
        <div>
          <div class="search-suggestion-title">Không tìm thấy kết quả cho "${query}"</div>
          <div class="search-suggestion-meta">Thử từ khóa khác</div>
        </div>
      </div>
    `;
    return;
  }

  searchSuggestions.innerHTML = results.map(post => `
    <a href="bai-viet.html?id=${post.id}" class="search-suggestion-item" style="text-decoration:none;">
      <div class="search-suggestion-icon"><i class="bi bi-file-text"></i></div>
      <div>
        <div class="search-suggestion-title">${Formatters.highlightText(post.title, query)}</div>
        <div class="search-suggestion-meta">${Formatters.readingTime(post.content || '')} · ${Formatters.formatDate(post.createdAt)}</div>
      </div>
    </a>
  `).join('');
};

const performSearch = (query) => {
  allPosts = allPosts.filter(p =>
    p.title.toLowerCase().includes(query.toLowerCase()) ||
    (p.content || '').toLowerCase().includes(query.toLowerCase())
  );
  renderPosts(allPosts);
  if (searchSuggestions) searchSuggestions.innerHTML = '';
  Helpers.scrollTo('#postsSection');
};

// ── Tags Cloud ──
const loadTagsCloud = async () => {
  const container = document.getElementById('tagsCloud');
  if (!container) return;

  try {
    // Use jQuery $.ajax for required demo
    $.ajax({
      url: API.TAGS_URL,
      method: 'GET',
      dataType: 'json',
      success: (tags) => {
        if (!Array.isArray(tags) || !tags.length) {
          // Fallback demo tags
          const demoTags = ['JavaScript', 'CSS', 'HTML', 'Design', 'React', 'Node.js', 'Python', 'UX', 'Startup', 'Tools'];
          container.innerHTML = demoTags.map(t => `<span class="tag-pill" data-tag="${t}">${t}</span>`).join('');
        } else {
          container.innerHTML = tags.slice(0, 12).map(t => `
            <span class="tag-pill" data-tag="${t.name}">${t.name}
              ${t.postCount ? `<span style="opacity:0.7;">(${t.postCount})</span>` : ''}
            </span>
          `).join('');
        }
        setupTagFilter();
      },
      error: () => {
        container.innerHTML = ['Tech', 'Design', 'JavaScript', 'CSS', 'Business', 'Life'].map(t =>
          `<span class="tag-pill" data-tag="${t}">${t}</span>`
        ).join('');
        setupTagFilter();
      },
    });
  } catch (err) {
    container.innerHTML = '';
  }
};

// ── Newsletter ──
const setupNewsletter = () => {
  if (!newsletterForm) return;

  newsletterForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const emailInput = newsletterForm.querySelector('input[type="email"]');
    const email = emailInput?.value?.trim();

    if (!email || Validators.isEmail(email)) {
      Toast.error('Email không hợp lệ', 'Vui lòng nhập địa chỉ email hợp lệ.');
      return;
    }

    Toast.success('Đăng ký thành công!', 'Bạn đã đăng ký nhận bản tin BlogHub.');
    if (emailInput) emailInput.value = '';
  });
};

// ── Init ──
document.addEventListener('DOMContentLoaded', initHome);
