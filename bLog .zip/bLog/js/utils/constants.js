/**
 * BlogHub - Constants
 * All app-wide constant values
 */

const CONSTANTS = {
  // App metadata
  APP_NAME: 'BlogHub',
  APP_TAGLINE: 'Nền tảng blog cá nhân của bạn',
  APP_VERSION: '1.0.0',

  // Admin account hardcoded for this mock project
  ADMIN_ACCOUNT: {
    email: 'admin@bloghub.com',
    password: 'admin123',
    name: 'BlogHub Admin',
    role: 'admin',
  },

  // Storage keys
  STORAGE_KEYS: {
    USER: 'bloghub_user',
    THEME: 'bloghub_theme',
    LIKED_POSTS: 'bloghub_liked_posts',
    DRAFT: 'bloghub_draft',
    REMEMBER_ME: 'bloghub_remember',
    RECENT_SEARCHES: 'bloghub_searches',
  },

  // Pagination
  POSTS_PER_PAGE: 9,
  COMMENTS_PER_PAGE: 10,
  TABLE_PER_PAGE: 10,
  SEARCH_DEBOUNCE_MS: 350,

  // Validation
  VALIDATION: {
    TITLE_MIN: 5,
    TITLE_MAX: 120,
    EXCERPT_MIN: 20,
    EXCERPT_MAX: 300,
    CONTENT_MIN: 20,
    PASSWORD_MIN: 6,
    COMMENT_MIN: 5,
    COMMENT_MAX: 1000,
    TAG_NAME_MIN: 2,
    TAG_NAME_MAX: 30,
  },

  // Post statuses
  POST_STATUS: {
    PUBLISHED: 'published',
    DRAFT: 'draft',
    ARCHIVED: 'archived',
  },

  // Trạng thái bình luận
  COMMENT_STATUS: {
    PENDING: 'pending',
    APPROVED: 'approved',
    REJECTED: 'rejected',
  },

  // Toast durations (ms)
  TOAST_DURATION: {
    SUCCESS: 3500,
    ERROR: 5000,
    WARNING: 4000,
    INFO: 3000,
  },

  // Nhãn trạng thái bài viết (Tiếng Việt)
  STATUS_LABELS: {
    published: 'Đã xuất bản',
    draft: 'Nháp',
    archived: 'Lưu trữ',
  },

  // Nhãn trạng thái bình luận (Tiếng Việt)
  COMMENT_STATUS_LABELS: {
    pending: 'Chờ duyệt',
    approved: 'Đã duyệt',
    rejected: 'Từ chối',
  },

  // Demo data for fallback
  DEMO_AVATAR: 'https://ui-avatars.com/api/?background=2563EB&color=fff&size=128&bold=true',

  // Tag colors
  TAG_COLORS: [
    { name: 'purple', label: 'Purple', value: '#6D28D9', bg: '#F5F3FF' },
    { name: 'blue',   label: 'Blue',   value: '#1D4ED8', bg: '#EFF6FF' },
    { name: 'green',  label: 'Green',  value: '#15803D', bg: '#F0FDF4' },
    { name: 'red',    label: 'Red',    value: '#DC2626', bg: '#FEF2F2' },
    { name: 'orange', label: 'Orange', value: '#C2410C', bg: '#FFF7ED' },
    { name: 'pink',   label: 'Pink',   value: '#BE185D', bg: '#FDF2F8' },
    { name: 'yellow', label: 'Yellow', value: '#A16207', bg: '#FEFCE8' },
    { name: 'cyan',   label: 'Cyan',   value: '#0E7490', bg: '#ECFEFF' },
    { name: 'indigo', label: 'Indigo', value: '#3730A3', bg: '#EEF2FF' },
    { name: 'gray',   label: 'Gray',   value: '#374151', bg: '#F9FAFB' },
  ],

  // Reading speed (words per minute)
  WORDS_PER_MINUTE: 200,

  // Nhãn tháng trên biểu đồ
  CHART_MONTHS: ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12'],

  // API endpoints
  ENDPOINTS: {
    POSTS: '/posts',
    COMMENTS: '/comments',
    TAGS: '/tags',
    USERS: '/users',
  },
};

// Freeze to prevent accidental mutations
Object.freeze(CONSTANTS);
Object.freeze(CONSTANTS.STORAGE_KEYS);
Object.freeze(CONSTANTS.ADMIN_ACCOUNT);
Object.freeze(CONSTANTS.VALIDATION);
Object.freeze(CONSTANTS.POST_STATUS);
Object.freeze(CONSTANTS.COMMENT_STATUS);
Object.freeze(CONSTANTS.TOAST_DURATION);
