/**
 * BlogHub - Helpers
 * General utility functions
 */

const Helpers = (() => {
  /**
   * Debounce function
   */
  const debounce = (fn, delay = 300) => {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  };

  /**
   * Throttle function
   */
  const throttle = (fn, limit = 100) => {
    let lastRun = 0;
    return function (...args) {
      const now = Date.now();
      if (now - lastRun >= limit) {
        lastRun = now;
        fn.apply(this, args);
      }
    };
  };

  /**
   * Get URL query parameter
   */
  const getQueryParam = (name) => {
    const params = new URLSearchParams(window.location.search);
    return params.get(name);
  };

  /**
   * Set multiple URL query parameters
   */
  const setQueryParams = (params) => {
    const url = new URL(window.location.href);
    Object.entries(params).forEach(([k, v]) => {
      if (v === null || v === undefined || v === '') {
        url.searchParams.delete(k);
      } else {
        url.searchParams.set(k, v);
      }
    });
    window.history.replaceState({}, '', url.toString());
  };

  /**
   * Generate a random ID
   */
  const randomId = (prefix = '') => {
    return `${prefix}${Math.random().toString(36).slice(2, 9)}`;
  };

  /**
   * Get initials from name
   */
  const getInitials = (name = '') => {
    return name
      .split(' ')
      .slice(0, 2)
      .map(n => n[0] || '')
      .join('')
      .toUpperCase();
  };

  /**
   * Generate avatar URL from name
   */
  const getAvatarUrl = (name, size = 64) => {
    const initials = encodeURIComponent(getInitials(name) || '?');
    return `https://ui-avatars.com/api/?name=${initials}&background=2563EB&color=fff&size=${size}&bold=true`;
  };

  /**
   * Get random placeholder image
   */
  const getPlaceholderImage = (width = 800, height = 500, seed = '') => {
    const topics = ['technology', 'nature', 'city', 'abstract', 'business'];
    const topic = seed || topics[Math.floor(Math.random() * topics.length)];
    return `https://source.unsplash.com/${width}x${height}/?${topic}&sig=${Math.random()}`;
  };

  /**
   * Scroll to element smoothly
   */
  const scrollTo = (selector, offset = 80) => {
    const el = typeof selector === 'string' ? document.querySelector(selector) : selector;
    if (!el) return;
    const top = el.getBoundingClientRect().top + window.scrollY - offset;
    window.scrollTo({ top, behavior: 'smooth' });
  };

  /**
   * Copy text to clipboard
   */
  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Fallback
      const el = document.createElement('textarea');
      el.value = text;
      el.style.position = 'fixed';
      el.style.opacity = '0';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      return true;
    }
  };

  /**
   * Strip HTML tags from string
   */
  const stripHtml = (html) => {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || '';
  };

  /**
   * Truncate string
   */
  const truncate = (str, length = 100, suffix = '...') => {
    if (!str) return '';
    if (str.length <= length) return str;
    return str.slice(0, length).trim() + suffix;
  };

  /**
   * Chunk array
   */
  const chunk = (arr, size) => {
    const chunks = [];
    for (let i = 0; i < arr.length; i += size) {
      chunks.push(arr.slice(i, i + size));
    }
    return chunks;
  };

  /**
   * Check if element is in viewport
   */
  const isInViewport = (el) => {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  };

  /**
   * Get random integer in range
   */
  const randomInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

  /**
   * Pick random item from array
   */
  const randomPick = (arr) => arr[randomInt(0, arr.length - 1)];

  /**
   * Shuffle array
   */
  const shuffle = (arr) => [...arr].sort(() => Math.random() - 0.5);

  /**
   * Group array by key
   */
  const groupBy = (arr, key) => {
    return arr.reduce((acc, item) => {
      const group = item[key];
      if (!acc[group]) acc[group] = [];
      acc[group].push(item);
      return acc;
    }, {});
  };

  return {
    debounce, throttle, getQueryParam, setQueryParams,
    randomId, getInitials, getAvatarUrl, getPlaceholderImage,
    scrollTo, copyToClipboard, stripHtml, truncate,
    chunk, isInViewport, randomInt, randomPick, shuffle, groupBy,
  };
})();
