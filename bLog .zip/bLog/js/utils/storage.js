/**
 * BlogHub - Storage Utility
 * LocalStorage/SessionStorage wrapper with type safety
 */

const Storage = (() => {
  // ── LocalStorage ──
  const set = (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.warn('Storage.set failed:', e);
      return false;
    }
  };

  const get = (key, defaultValue = null) => {
    try {
      const item = localStorage.getItem(key);
      if (item === null) return defaultValue;
      return JSON.parse(item);
    } catch (e) {
      console.warn('Storage.get failed:', e);
      return defaultValue;
    }
  };

  const remove = (key) => {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (e) {
      return false;
    }
  };

  const clear = () => {
    try {
      localStorage.clear();
      return true;
    } catch (e) {
      return false;
    }
  };

  // ── User session ──
  const getUser = () => get(CONSTANTS.STORAGE_KEYS.USER);

  const setUser = (user) => set(CONSTANTS.STORAGE_KEYS.USER, user);

  const removeUser = () => remove(CONSTANTS.STORAGE_KEYS.USER);

  const isLoggedIn = () => {
    const user = getUser();
    return user !== null && typeof user === 'object' && !!user.id;
  };

  const isAdmin = () => {
    const user = getUser();
    const adminEmail = CONSTANTS.ADMIN_ACCOUNT.email.toLowerCase();
    return isLoggedIn() &&
      user.role === 'admin' &&
      String(user.email || '').toLowerCase() === adminEmail;
  };

  // ── Theme ──
  const getTheme = () => get(CONSTANTS.STORAGE_KEYS.THEME, 'light');

  const setTheme = (theme) => set(CONSTANTS.STORAGE_KEYS.THEME, theme);

  // ── Liked posts ──
  const getLikedPosts = () => get(CONSTANTS.STORAGE_KEYS.LIKED_POSTS, []);

  const addLikedPost = (postId) => {
    const liked = getLikedPosts();
    if (!liked.includes(postId)) {
      liked.push(postId);
      set(CONSTANTS.STORAGE_KEYS.LIKED_POSTS, liked);
    }
  };

  const isPostLiked = (postId) => getLikedPosts().includes(postId);

  // ── Draft ──
  const getDraft = () => get(CONSTANTS.STORAGE_KEYS.DRAFT);
  const setDraft = (data) => set(CONSTANTS.STORAGE_KEYS.DRAFT, { ...data, savedAt: Date.now() });
  const clearDraft = () => remove(CONSTANTS.STORAGE_KEYS.DRAFT);

  // ── Recent searches ──
  const getRecentSearches = () => get(CONSTANTS.STORAGE_KEYS.RECENT_SEARCHES, []);

  const addRecentSearch = (query) => {
    if (!query || query.length < 2) return;
    let searches = getRecentSearches();
    searches = [query, ...searches.filter(s => s !== query)].slice(0, 8);
    set(CONSTANTS.STORAGE_KEYS.RECENT_SEARCHES, searches);
  };

  return {
    set, get, remove, clear,
    getUser, setUser, removeUser, isLoggedIn, isAdmin,
    getTheme, setTheme,
    getLikedPosts, addLikedPost, isPostLiked,
    getDraft, setDraft, clearDraft,
    getRecentSearches, addRecentSearch,
  };
})();
