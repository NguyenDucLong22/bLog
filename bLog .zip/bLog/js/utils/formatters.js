/**
 * BlogHub - Formatters
 * Date, number, and text formatting utilities
 */

const Formatters = (() => {
  /**
   * Format ISO date to readable string
   */
  const formatDate = (dateValue, options = {}) => {
    if (!dateValue) return 'Không rõ ngày';
    
    // Convert MockAPI unix timestamp (seconds or milliseconds) to valid Date
    let date;
    if (typeof dateValue === 'number' || (typeof dateValue === 'string' && !isNaN(Number(dateValue)))) {
      const numDate = Number(dateValue);
      // If it's in seconds (e.g., 1778121720), multiply by 1000
      date = new Date(numDate < 10000000000 ? numDate * 1000 : numDate);
    } else {
      date = new Date(dateValue);
    }

    if (isNaN(date.getTime())) return 'Ngày không hợp lệ';
    const defaultOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return date.toLocaleDateString('vi-VN', { ...defaultOptions, ...options });
  };

  /**
   * Format date as relative time (e.g., "3 hours ago")
   */
  const timeAgo = (dateValue) => {
    if (!dateValue) return '';
    
    let date;
    if (typeof dateValue === 'number' || (typeof dateValue === 'string' && !isNaN(Number(dateValue)))) {
      const numDate = Number(dateValue);
      date = new Date(numDate < 10000000000 ? numDate * 1000 : numDate);
    } else {
      date = new Date(dateValue);
    }

    if (isNaN(date.getTime())) return '';

    const now = new Date();
    const diffMs = now - date;
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);
    const diffWeek = Math.floor(diffDay / 7);
    const diffMonth = Math.floor(diffDay / 30);
    const diffYear = Math.floor(diffDay / 365);

    if (diffSec < 60) return 'vừa xong';
    if (diffMin < 60) return `${diffMin} phút trước`;
    if (diffHour < 24) return `${diffHour} giờ trước`;
    if (diffDay < 7) return `${diffDay} ngày trước`;
    if (diffWeek < 4) return `${diffWeek} tuần trước`;
    if (diffMonth < 12) return `${diffMonth} tháng trước`;
    return `${diffYear} năm trước`;
  };

  /**
   * Format number with k/M suffixes
   */
  const formatNumber = (num) => {
    if (num === null || num === undefined) return '0';
    if (num >= 1_000_000) return (num / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
    if (num >= 1_000) return (num / 1_000).toFixed(1).replace(/\.0$/, '') + 'k';
    return String(num);
  };

  /**
   * Estimate reading time from content
   */
  const readingTime = (content = '') => {
    const text = content.replace(/<[^>]*>/g, '');
    const wordCount = text.trim().split(/\s+/).filter(w => w.length > 0).length;
    const minutes = Math.ceil(wordCount / CONSTANTS.WORDS_PER_MINUTE);
    return minutes < 1 ? '1 phút đọc' : `${minutes} phút đọc`;
  };

  /**
   * Format file size in bytes
   */
  const fileSize = (bytes) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  /**
   * Format percentage
   */
  const percentage = (value, total, decimals = 1) => {
    if (!total) return '0%';
    return `${((value / total) * 100).toFixed(decimals)}%`;
  };

  /**
   * Slug from title
   */
  const toSlug = (title) => {
    return title
      .toLowerCase()
      .replace(/[^\w\s-]/g, '')
      .replace(/[\s_-]+/g, '-')
      .replace(/^-+|-+$/g, '');
  };

  /**
   * Format tags array to HTML pills
   */
  const formatTags = (tags = [], clickable = true) => {
    if (!Array.isArray(tags) || tags.length === 0) return '';
    return tags.map(tag => {
      if (clickable) {
        return `<a href="index.html?tag=${encodeURIComponent(tag)}" class="tag-pill">${tag}</a>`;
      }
      return `<span class="tag-pill">${tag}</span>`;
    }).join('');
  };

  /**
   * Format post status badge
   */
  const statusBadge = (status) => {
    const map = {
      published: '<span class="badge-custom badge-green"><i class="bi bi-check-circle"></i> Đã xuất bản</span>',
      draft:     '<span class="badge-custom badge-yellow"><i class="bi bi-pencil"></i> Nháp</span>',
      archived:  '<span class="badge-custom badge-gray"><i class="bi bi-archive"></i> Lưu trữ</span>',
    };
    return map[status] || `<span class="badge-custom badge-gray">${status}</span>`;
  };

  /**
   * Format comment status badge
   */
  const commentStatusBadge = (status) => {
    const map = {
      approved: '<span class="comment-status-badge comment-status-approved"><i class="bi bi-check"></i> Đã duyệt</span>',
      pending:  '<span class="comment-status-badge comment-status-pending"><i class="bi bi-clock"></i> Chờ duyệt</span>',
      rejected: '<span class="comment-status-badge comment-status-rejected"><i class="bi bi-x"></i> Từ chối</span>',
    };
    return map[status] || `<span class="comment-status-badge">${status}</span>`;
  };
  /**
   * Highlight search term in text
   */
  const highlightText = (text, query) => {
    if (!query || !text) return text;
    const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    return text.replace(regex, '<mark>$1</mark>');
  };

  /**
   * Format currency (for future use)
   */
  const currency = (amount, locale = 'en-US', currency = 'USD') => {
    return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(amount);
  };

  return {
    formatDate, timeAgo, formatNumber, readingTime,
    fileSize, percentage, toSlug, formatTags,
    statusBadge, commentStatusBadge, highlightText, currency,
  };
})();
