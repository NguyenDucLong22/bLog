/**
 * BlogHub - Validators
 * Form validation rules and utilities
 */

const Validators = (() => {
  // ── Individual validators ──

  const required = (value, label = 'Field') => {
    if (!value || String(value).trim().length === 0) {
      return `${label} is required`;
    }
    return null;
  };

  const minLength = (value, min, label = 'Field') => {
    if (!value || String(value).trim().length < min) {
      return `${label} must be at least ${min} characters`;
    }
    return null;
  };

  const maxLength = (value, max, label = 'Field') => {
    if (value && String(value).trim().length > max) {
      return `${label} must not exceed ${max} characters`;
    }
    return null;
  };

  const isEmail = (value) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!regex.test(value)) {
      return 'Please enter a valid email address';
    }
    return null;
  };

  const isUrl = (value) => {
    if (!value) return null; // Optional URL
    try {
      new URL(value);
      return null;
    } catch {
      return 'Please enter a valid URL (include https://)';
    }
  };

  const isImageUrl = (value) => {
    if (!value) return null;
    const urlError = isUrl(value);
    if (urlError) return urlError;
    const imageExtensions = /\.(jpg|jpeg|png|gif|webp|svg|avif)(\?.*)?$/i;
    if (!imageExtensions.test(value)) {
      return 'Please enter a valid image URL (.jpg, .png, .webp, etc.)';
    }
    return null;
  };

  const noSpecialChars = (value, label = 'Field') => {
    const regex = /^[a-zA-Z0-9\s\-_\.]+$/;
    if (!regex.test(value)) {
      return `${label} contains invalid characters`;
    }
    return null;
  };

  const isPasswordStrong = (value) => {
    if (!value || value.length < CONSTANTS.VALIDATION.PASSWORD_MIN) {
      return `Password must be at least ${CONSTANTS.VALIDATION.PASSWORD_MIN} characters`;
    }
    return null;
  };

  // ── Form validators ──

  const validateLoginForm = (data) => {
    const errors = {};
    const emailErr = required(data.email, 'Email') || isEmail(data.email);
    const passErr = required(data.password, 'Mật khẩu') || isPasswordStrong(data.password);
    if (emailErr) errors.email = emailErr;
    if (passErr) errors.password = passErr;
    return errors;
  };

  const validateRegisterForm = (data) => {
    const errors = {};
    const nameErr = required(data.name, 'Họ tên') || minLength(data.name, 2, 'Họ tên');
    const emailErr = required(data.email, 'Email') || isEmail(data.email);
    const passErr = required(data.password, 'Mật khẩu') || isPasswordStrong(data.password);
    const confirmErr = required(data.confirmPassword, 'Nhập lại mật khẩu');

    if (nameErr) errors.name = nameErr;
    if (emailErr) errors.email = emailErr;
    if (passErr) errors.password = passErr;
    if (confirmErr) errors.confirmPassword = confirmErr;
    if (!confirmErr && data.password !== data.confirmPassword) {
      errors.confirmPassword = 'Mật khẩu nhập lại không khớp';
    }

    return errors;
  };

  const validatePostForm = (data) => {
    const errors = {};
    const V = CONSTANTS.VALIDATION;

    const titleErr = required(data.title, 'Title') || minLength(data.title, V.TITLE_MIN, 'Title') || maxLength(data.title, V.TITLE_MAX, 'Title');
    const contentErr = required(data.content, 'Content') || minLength(data.content, V.CONTENT_MIN, 'Content');
    const excerptErr = data.excerpt ? maxLength(data.excerpt, V.EXCERPT_MAX, 'Excerpt') : null;
    const imageErr = isImageUrl(data.image);

    if (titleErr) errors.title = titleErr;
    if (contentErr) errors.content = contentErr;
    if (excerptErr) errors.excerpt = excerptErr;
    if (imageErr) errors.image = imageErr;

    return errors;
  };

  const validateCommentForm = (data) => {
    const errors = {};
    const V = CONSTANTS.VALIDATION;
    const nameErr = required(data.name, 'Name') || minLength(data.name, 2, 'Name');
    const emailErr = required(data.email, 'Email') || isEmail(data.email);
    const contentErr = required(data.content, 'Comment') || minLength(data.content, V.COMMENT_MIN, 'Comment') || maxLength(data.content, V.COMMENT_MAX, 'Comment');
    if (nameErr) errors.name = nameErr;
    if (emailErr) errors.email = emailErr;
    if (contentErr) errors.content = contentErr;
    return errors;
  };

  const validateTagForm = (data) => {
    const errors = {};
    const V = CONSTANTS.VALIDATION;
    const nameErr = required(data.name, 'Tag name') || minLength(data.name, V.TAG_NAME_MIN, 'Tag name') || maxLength(data.name, V.TAG_NAME_MAX, 'Tag name');
    if (nameErr) errors.name = nameErr;
    return errors;
  };

  // ── UI helpers ──

  /**
   * Display validation errors in the form
   * @param {object} errors - { fieldId: errorMsg }
   */
  const displayErrors = (errors) => {
    // Clear previous errors
    document.querySelectorAll('.form-error').forEach(el => el.remove());
    document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));

    Object.entries(errors).forEach(([field, message]) => {
      const input = document.getElementById(field) || document.querySelector(`[name="${field}"]`);
      if (!input) return;

      input.classList.add('is-invalid');

      const errorEl = document.createElement('p');
      errorEl.className = 'form-error';
      errorEl.innerHTML = `<i class="bi bi-exclamation-circle"></i> ${message}`;

      const parent = input.closest('.form-group') || input.parentElement;
      parent.appendChild(errorEl);
    });
  };

  /**
   * Mark a field as valid
   */
  const markValid = (inputId) => {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.classList.remove('is-invalid');
    input.classList.add('is-valid');
    const err = input.parentElement.querySelector('.form-error');
    if (err) err.remove();
  };

  /**
   * Clear all validation states from a form
   */
  const clearForm = (formEl) => {
    if (!formEl) return;
    formEl.querySelectorAll('.is-invalid, .is-valid').forEach(el => {
      el.classList.remove('is-invalid', 'is-valid');
    });
    formEl.querySelectorAll('.form-error').forEach(el => el.remove());
  };

  const hasErrors = (errors) => Object.keys(errors).length > 0;

  return {
    required, minLength, maxLength, isEmail, isUrl, isImageUrl,
    noSpecialChars, isPasswordStrong,
    validateLoginForm, validateRegisterForm, validatePostForm, validateCommentForm, validateTagForm,
    displayErrors, markValid, clearForm, hasErrors,
  };
})();
