# Huong dan MockAPI BlogHub

## Link API dang gan

Project MockAPI dang dung:

```text
https://69e986ab55d62f34797a96da.mockapi.io/api/v1
```

App se goi:

```text
https://69e986ab55d62f34797a96da.mockapi.io/api/v1/users
https://69e986ab55d62f34797a96da.mockapi.io/api/v1/posts
```

## Tai khoan admin rieng

Admin co san trong code, khong can dang ky:

```text
Email: admin@bloghub.com
Mat khau: admin123
```

Chi tai khoan nay vao duoc:

```text
dashboard.html
dang-bai.html
quan-ly-bai-viet.html
quan-ly-binh-luan.html
quan-ly-tags.html
```

Tai khoan dang ky moi se duoc ghi vao MockAPI resource `users` voi `role = user`, khong vao duoc admin.

## Resource users

Tao resource ten:

```text
users
```

Field nen co:

```text
name        Text
email       Text
password    Text
role        Text
avatar      Text
createdAt   Date
updatedAt   Date
```

## Resource posts

Tao resource ten:

```text
posts
```

Field nen co:

```text
title       Text
content     Text
excerpt     Text
image       Text
thumbnail   Text
tags        Array
status      Text
author      Text
likes       Number
views       Number
createdAt   Date
updatedAt   Date
```

## Nen tao them cho dep

Tao them `comments` de chay binh luan:

```text
postId      Text
name        Text
email       Text
content     Text
status      Text
likes       Number
createdAt   Date
updatedAt   Date
```

Tao them `tags` de chay goi y tag:

```text
name        Text
slug        Text
color       Text
postCount   Number
createdAt   Date
```
